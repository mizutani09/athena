//========================================================================================
// Athena++ astrophysical MHD code
// Copyright(C) 2014 James M. Stone <jmstone@princeton.edu> and other code contributors
// Licensed under the 3-clause BSD License, see LICENSE file for details
//========================================================================================
//! \file NRFLD.cpp
//! \brief implementation of the functions used in FLD

// C headers

// C++ headers
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>    // memset, memcpy
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>    // stringstream
#include <stdexcept>  // runtime_error
#include <string>     // c_str()

// Athena++ headers
#include "../athena.hpp"
#include "../athena_arrays.hpp"
#include "../coordinates/coordinates.hpp"
#include "../eos/eos.hpp"
#include "../linear_solver/linear_solver.hpp"
#include "../mesh/mesh.hpp"
#include "../parameter_input.hpp"
#include "NRFLD.hpp"


namespace {

// In the optically thick LTE limit, the Newton solve can only place a*T^4 and
// Er on adjacent floating-point numbers.  Their subtraction then changes sign
// from one Newton iteration to the next, and c*sigma amplifies that irreducible
// roundoff into a large, grid-dependent source.  Treat differences within the
// rounding error of the temperature-to-energy conversion as zero.  The factor
// allows for the multiply chain T = DCOUPLE*egas and a*T*T*T*T.
inline Real ResolvableThermalDifference(Real equilibrium_rad, Real u_rad) {
  const Real difference = equilibrium_rad - u_rad;
  const Real scale = std::max(std::abs(equilibrium_rad), std::abs(u_rad));
  const Real roundoff = 32.0*std::numeric_limits<Real>::epsilon()*scale;
  return (std::abs(difference) <= roundoff) ? 0.0 : difference;
}

inline RadFLD::ClosureValues RequireFaceClosure(const Real gradient,
                                                const Real opacity,
                                                const Real erad,
                                                const bool fixed,
                                                const char *face, const int k,
                                                const int j, const int i) {
  const RadFLD::ClosureValues closure =
      RadFLD::EvaluateClosure(gradient, opacity, erad, fixed);
  if (!closure.valid) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NR-FLD face closure at " << face
        << " cell (k,j,i)=(" << k << "," << j << "," << i << ")"
        << ": gradient=" << gradient << " opacity=" << opacity
        << " Er=" << erad
        << ". Opacity and Er must be finite and non-negative;"
        << " fixed limiter with zero opacity and nonzero gradient is unsupported.\n";
    ATHENA_ERROR(msg);
  }
  return closure;
}

inline Real FaceGradient(const Real gx, const Real gy, const Real gz) {
  return std::hypot(gx, std::hypot(gy, gz));
}

inline Real FaceEnergy(const Real left, const Real right) {
  return 0.5*left + 0.5*right;
}

enum DriftFace { XMinus, XPlus, YMinus, YPlus, ZMinus, ZPlus };

inline bool MarshakFaceActive(const MeshBlock *pmb, const FLD *fld,
                              const int face, const int k, const int j,
                              const int i) {
  // cut_diff removes the entire diffusion operator, including its physical
  // boundary flux.  Keeping a Marshak face here changes the supposedly local
  // exchange problem and defeats its total-energy cancellation.
  if (fld->cut_diff) return false;
  const bool enabled = fld->marshak_face_boundary[face]
      || (face == ZPlus && fld->marshak_top_boundary);
  if (!enabled) return false;
  const RegionSize &block = pmb->block_size;
  const RegionSize &mesh = pmb->pmy_mesh->mesh_size;
  if (face == XMinus) return i == pmb->is && block.x1min == mesh.x1min;
  if (face == XPlus)  return i == pmb->ie && block.x1max == mesh.x1max;
  if (face == YMinus) return j == pmb->js && block.x2min == mesh.x2min;
  if (face == YPlus)  return j == pmb->je && block.x2max == mesh.x2max;
  if (face == ZMinus) return k == pmb->ks && block.x3min == mesh.x3min;
  return k == pmb->ke && block.x3max == mesh.x3max;
}

inline Real MarshakFlux(const FLD *fld, const int face, const int k,
                        const int j, const int i, const Real erad,
                        const Real dx, Real *derivative) {
  const Real dface = std::max(fld->marshak_dface_all(face,k,j,i), TINY_NUMBER);
  const Real acoef = fld->marshak_top_alpha*fld->c_ph*0.5*dx;
  const Real denom = std::max(dface + acoef, TINY_NUMBER);
  const Real eb = (dface*erad + acoef*fld->marshak_top_erad_ext)/denom;
  if (derivative != nullptr) {
    *derivative = fld->marshak_top_alpha*fld->c_ph*dface/denom;
  }
  return fld->marshak_top_alpha*fld->c_ph
      *(eb - fld->marshak_top_erad_ext);
}

inline Real MixedDriftFace(const RadFLD::ClosureValues &closure,
                           Real sigma_p_left, Real sigma_p_right,
                           Real velocity_left, Real velocity_right) {
  // q_face*v_face = 2*lambda_face*(sigma_P/sigma_R)_face*v_face.
  const Real drift = 0.5*(sigma_p_left + sigma_p_right)
      *(velocity_left + velocity_right)*closure.lambda_over_opacity;
  if (!std::isfinite(drift)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NR-FLD implicit mixed-frame face coefficient: "
        << "q*v is not finite.\n";
    ATHENA_ERROR(msg);
  }
  return drift;
}

template <typename EnergyAt>
inline Real MixedDriftStencil(const AthenaArray<Real> &drift,
                              const EnergyAt &energy_at,
                              int k, int j, int i, Real half_idx) {
  const Real center = energy_at(k,j,i);
  return half_idx*(
      drift(XPlus,k,j,i)*(energy_at(k,j,i+1)-center)
    + drift(XMinus,k,j,i)*(center-energy_at(k,j,i-1))
    + drift(YPlus,k,j,i)*(energy_at(k,j+1,i)-center)
    + drift(YMinus,k,j,i)*(center-energy_at(k,j-1,i))
    + drift(ZPlus,k,j,i)*(energy_at(k+1,j,i)-center)
    + drift(ZMinus,k,j,i)*(center-energy_at(k-1,j,i)));
}

inline Real MixedDriftTerm(const AthenaArray<Real> &drift,
                           const AthenaArray<Real> &erad,
                           int k, int j, int i, Real half_idx) {
  return MixedDriftStencil(drift,
      [&erad](int z, int y, int x) { return erad(z,y,x); }, k,j,i,half_idx);
}

inline Real MixedDriftCorrection(const AthenaArray<Real> &drift,
                                  const AthenaArray<Real> &delta,
                                  int k, int j, int i, Real half_idx) {
  return MixedDriftStencil(drift,
      [&delta](int z, int y, int x) { return delta(1,z,y,x); },
      k,j,i,half_idx);
}

inline Real LimitNewtonCorrection(Real delta, Real scale, Real max_fraction) {
  if (max_fraction <= 0.0) return delta;
  const Real limit = max_fraction*scale;
  return std::max(-limit, std::min(limit, delta));
}

}  // namespace

//----------------------------------------------------------------------------------------
//! \fn NRFLDDriver::NRFLDDriver(Mesh *pm, ParameterInput *pin)
//! \brief NRFLDDriver constructor

NRFLDDriver::NRFLDDriver(Mesh *pm, ParameterInput *pin)
    : NewtonRaphsonDriver(pm, 1, linearSolver::NCOEFF, linearSolver::NMATRIX) {
  eps_ = pin->GetOrAddReal("nrfld", "nr_threshold", -1.0);
  global_jv_ = pin->GetOrAddBoolean("nrfld", "global_jacobian_check", false);
  global_jv_iteration_ = pin->GetOrAddInteger("nrfld", "global_jacobian_iteration", 0);
  global_jv_epsilon_ = pin->GetOrAddReal("nrfld", "global_jacobian_epsilon", 1.e-4);
  if (global_jv_iteration_ < 0 || !(global_jv_epsilon_ > 0.0)
      || !std::isfinite(global_jv_epsilon_)) {
    std::stringstream msg;
    msg << "Invalid global_jacobian_iteration/epsilon";
    ATHENA_ERROR(msg);
  }
  relaxed_l2_eps_ = pin->GetOrAddReal(
      "nrfld", "nr_accept_l2_threshold", -1.0);
  relaxed_max_eps_ = pin->GetOrAddReal(
      "nrfld", "nr_accept_max_threshold", -1.0);
  niter_ = pin->GetOrAddInteger("nrfld", "nr_niteration", -1);
  nr_max_iterations_ = pin->GetOrAddInteger("nrfld", "nr_max_iterations", 100);
  const bool verbosity_in_input =
      pin->DoesParameterExist("nrfld", "diagnostic_verbosity") != 0;
  fshowdef_ = pin->GetOrAddBoolean("nrfld", "show_defect", fshowdef_);
  diagnostic_verbosity_ = pin->GetOrAddInteger(
      "nrfld", "diagnostic_verbosity", fshowdef_ ? 2 : 0);
  const std::string failure_policy = pin->GetOrAddString(
      "nrfld", "failure_policy", "abort");
  if (failure_policy == "abort") {
    abort_on_failure_ = true;
  } else if (failure_policy == "warn_keep_old") {
    abort_on_failure_ = false;
  } else {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"failure_policy\" must be abort or warn_keep_old." << std::endl;
    ATHENA_ERROR(msg);
  }
  // show_defect remains a compatibility alias for the former all-or-nothing
  // diagnostics.  An explicit verbosity setting takes precedence.
  if (!verbosity_in_input && fshowdef_) diagnostic_verbosity_ = 2;
  fshowdef_ = diagnostic_verbosity_ > 0;
  use_mg_smoothing_fallback_ =
      pin->GetOrAddBoolean("nrfld", "nr_use_mg_smoothing_fallback", false);
  mg_coarse_retry_max_ = pin->GetOrAddInteger("nrfld", "nr_mg_coarse_retry_max", 0);
  mg_coarse_retry_factor_ =
      pin->GetOrAddReal("nrfld", "nr_mg_coarse_retry_factor", 0.5);
  mg_coarse_retry_min_scale_ =
      pin->GetOrAddReal("nrfld", "nr_mg_coarse_retry_min_scale", 0.0625);
  max_backtrack_ = pin->GetOrAddInteger("nrfld", "nr_backtrack_max", 4);
  backtrack_factor_ = pin->GetOrAddReal("nrfld", "nr_backtrack_factor", 0.5);
  min_step_scale_ = pin->GetOrAddReal("nrfld", "nr_min_step_scale", 0.05);
  if (eps_ < 0.0 && niter_ < 0) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "Either \"nr_threshold\" or \"nr_niteration\" parameter must be set "
        << "in the <nrfld> block." << std::endl
        << "When both parameters are specified, \"nr_niteration\" is ignored." << std::endl
        << "Set \"nr_threshold = 0.0\" for automatic convergence control." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (diagnostic_verbosity_ < 0 || diagnostic_verbosity_ > 2) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"diagnostic_verbosity\" must be 0 (off), 1 (iteration "
        << "summary), or 2 (maximum-cell stencil)." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (niter_ < -1) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_niteration\" must be >= 0 or omitted." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (!std::isfinite(eps_)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_threshold\" must be finite." << std::endl;
    ATHENA_ERROR(msg);
  }
  const bool relaxed_l2_set = relaxed_l2_eps_ > 0.0;
  const bool relaxed_max_set = relaxed_max_eps_ > 0.0;
  if (relaxed_l2_set != relaxed_max_set
      || !std::isfinite(relaxed_l2_eps_)
      || !std::isfinite(relaxed_max_eps_)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_accept_l2_threshold\" and \"nr_accept_max_threshold\" "
        << "must either both be finite and positive, or both be omitted." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (relaxed_l2_set && eps_ > 0.0
      && (relaxed_l2_eps_ < eps_ || relaxed_max_eps_ < eps_)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "Relaxed acceptance thresholds must be no smaller than nr_threshold."
        << std::endl;
    ATHENA_ERROR(msg);
  }
  if (relaxed_l2_set && Globals::my_rank == 0) {
    std::cout << "[NR_RELAXED_CONFIG] target=" << eps_
              << " accept_l2=" << relaxed_l2_eps_
              << " accept_max=" << relaxed_max_eps_ << std::endl;
  }
  if (nr_max_iterations_ <= 0) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_max_iterations\" must be positive." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (max_backtrack_ < 0) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_backtrack_max\" must be >= 0." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (!(backtrack_factor_ > 0.0 && backtrack_factor_ < 1.0)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_backtrack_factor\" must satisfy 0 < factor < 1." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (!(min_step_scale_ > 0.0 && min_step_scale_ <= 1.0)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_min_step_scale\" must satisfy 0 < scale <= 1." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (mg_coarse_retry_max_ < 0) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_mg_coarse_retry_max\" must be >= 0." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (!(mg_coarse_retry_factor_ > 0.0 && mg_coarse_retry_factor_ < 1.0)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_mg_coarse_retry_factor\" must satisfy 0 < factor < 1." << std::endl;
    ATHENA_ERROR(msg);
  }
  if (!(mg_coarse_retry_min_scale_ > 0.0 && mg_coarse_retry_min_scale_ <= 1.0)) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLDDriver::NRFLDDriver" << std::endl
        << "\"nr_mg_coarse_retry_min_scale\" must satisfy 0 < scale <= 1." << std::endl;
    ATHENA_ERROR(msg);
  }
//   fldtlist_ = new FLDBoundaryTaskList(pin, pm);

//   int nth = 1;
// #ifdef OPENMP_PARALLEL
//   nth = omp_get_max_threads();
// #endif
//   temp = new AthenaArray<Real>[nth];
//   int nx = std::max(pmy_mesh_->block_size.nx1, pmy_mesh_->nrbx1) + 2*mgroot_->ngh_;
//   int ny = std::max(pmy_mesh_->block_size.nx2, pmy_mesh_->nrbx2) + 2*mgroot_->ngh_;
//   int nz = std::max(pmy_mesh_->block_size.nx3, pmy_mesh_->nrbx3) + 2*mgroot_->ngh_;
//   for (int n = 0; n < nth; ++n)
//     temp[n].NewAthenaArray(nz, ny, nx);

  if (NRMGFLD_ENABLED) {
    plmgd_ = new linearMGDriver(pm, pin, this);
    pmy_mesh_->pmlmd = plmgd_;

    nr_mesh_bcs_[inner_x1] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ix1_bc", "none"));
    nr_mesh_bcs_[outer_x1] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ox1_bc", "none"));
    nr_mesh_bcs_[inner_x2] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ix2_bc", "none"));
    nr_mesh_bcs_[outer_x2] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ox2_bc", "none"));
    nr_mesh_bcs_[inner_x3] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ix3_bc", "none"));
    nr_mesh_bcs_[outer_x3] =
                GetBoundaryFlag(pin->GetOrAddString("nrfld", "ox3_bc", "none"));
    CheckBoundaryFunctions();
  } else {
    std::stringstream msg;
    msg << "### FATAL ERROR in NewtonRaphsonDriver::NewtonRaphsonDriver" << std::endl
        << "Failed to allocate linear solver" << std::endl;
    ATHENA_ERROR(msg);
  }
}


//----------------------------------------------------------------------------------------
//! \fn NRFLDDriver::~NRFLDDriver()
//! \brief NRFLDDriver destructor

NRFLDDriver::~NRFLDDriver() {
  const bool trace_dtor = (std::getenv("ATHENA_TRACE_DTOR") != nullptr);
  if (NRMGFLD_ENABLED) {
    if (trace_dtor) std::cout << "[DTOR] NRFLDDriver delete plmgd_" << std::endl;
    delete plmgd_;
  }
}

void NRFLDDriver::RunCommittedDiagnostic() {
  if (vnr_.empty() || dt_ <= 0.0) return;
  FLD *first = static_cast<NRFLD*>(vnr_.front())->pmy_block_->prfld;
  if (std::getenv("ATHENA_NRFLD_ENERGY_LEDGER") != nullptr
      && first->is_couple && !first->only_rad && !first->fixed_u_rad) {
    long double gas_delta = 0.0L, radiation_delta = 0.0L;
    long double diffusion_delta = 0.0L, boundary_delta = 0.0L;
    long double absolute_scale = 0.0L, absolute_balance = 0.0L;
    for (auto base : vnr_) {
      NRFLD *nr = static_cast<NRFLD*>(base);
      MeshBlock *mb = nr->pmy_block_;
      FLD *fld = mb->prfld;
      const Real dx = mb->pcoord->dx1f(mb->is);
      const Real idx2 = 1.0/SQR(dx);
      for (int k=mb->ks; k<=mb->ke; ++k)
        for (int j=mb->js; j<=mb->je; ++j)
          for (int i=mb->is; i<=mb->ie; ++i) {
            const Real center = nr->u_(k,j,i);
            const Real face_coeff[6] = {
              -nr->coeff_(linearSolver::DXMF,k,j,i),
              -nr->coeff_(linearSolver::DXPF,k,j,i),
              -nr->coeff_(linearSolver::DYMF,k,j,i),
              -nr->coeff_(linearSolver::DYPF,k,j,i),
              -nr->coeff_(linearSolver::DZMF,k,j,i),
              -nr->coeff_(linearSolver::DZPF,k,j,i)};
            const Real neighbor[6] = {nr->u_(k,j,i-1),nr->u_(k,j,i+1),
              nr->u_(k,j-1,i),nr->u_(k,j+1,i),nr->u_(k-1,j,i),nr->u_(k+1,j,i)};
            Real face_sum = 0.0, boundary_sum = 0.0;
            for (int face=0; face<6; ++face) {
              if (MarshakFaceActive(mb,fld,face,k,j,i)) {
                const Real contribution = -MarshakFlux(
                    fld,face,k,j,i,center,dx,nullptr)*dx;
                face_sum += contribution;
                boundary_sum += contribution;
              } else {
                face_sum += face_coeff[face]*(neighbor[face]-center);
              }
            }
            const Real volume = mb->pcoord->GetCellVolume(k,j,i);
            const Real dg = nr->u_gas_(k,j,i)-fld->u_gas(k,j,i);
            const Real dr = center-nr->uold_(k,j,i);
            const Real dd = dt_*face_sum*idx2;
            const Real residual = (dg+dr)-dd;
            gas_delta += static_cast<long double>(dg)*volume;
            radiation_delta += static_cast<long double>(dr)*volume;
            diffusion_delta += static_cast<long double>(dd)*volume;
            boundary_delta += static_cast<long double>(dt_*boundary_sum*idx2)*volume;
            absolute_balance += static_cast<long double>(std::abs(residual))*volume;
            absolute_scale += (static_cast<long double>(std::abs(dg))
                + std::abs(dr) + std::abs(dd)
                + std::abs(nr->u_gas_(k,j,i)) + std::abs(center))*volume;
          }
    }
    const long double balance = gas_delta+radiation_delta-diffusion_delta;
    const long double scale = std::max(absolute_scale, 1.0e-30L);
    const auto flags = std::cout.flags();
    const auto precision = std::cout.precision();
    std::cout << std::scientific << std::setprecision(16)
              << "[NR_ENERGY_LEDGER] rank=" << Globals::my_rank
              << " cycle=" << pmy_mesh_->ncycle << " stage=" << stage_
              << " dt=" << dt_ << " gas_delta=" << gas_delta
              << " radiation_delta=" << radiation_delta
              << " diffusion_delta=" << diffusion_delta
              << " marshak_delta=" << boundary_delta
              << " interior_delta=" << diffusion_delta-boundary_delta
              << " balance=" << balance
              << " relative_balance=" << std::abs(balance)/scale
              << " absolute_relative_balance=" << absolute_balance/scale
              << std::endl;
    std::cout.flags(flags);
    std::cout.precision(precision);
  }
  if (!first->MixedFrameCoupled()
      || mixed_frame_ledger_count_ >= first->mixed_frame_ledger_limit) return;
  ++mixed_frame_ledger_count_;
  Real q_gas_volume = 0.0;
  Real q_abs_volume = 0.0;
  for (auto base : vnr_) {
    NRFLD *nr = static_cast<NRFLD*>(base);
    MeshBlock *mb = nr->pmy_block_;
    if (!mb->prfld->implicit_mixed_frame_drift) continue;
    const Real half_idx = 0.5/mb->pcoord->dx1f(mb->is);
    for (int k = mb->ks; k <= mb->ke; ++k)
      for (int j = mb->js; j <= mb->je; ++j)
        for (int i = mb->is; i <= mb->ie; ++i) {
          const Real contribution = dt_*MixedDriftTerm(
              nr->mixed_drift_, nr->u_, k,j,i,half_idx)
              *mb->pcoord->GetCellVolume(k,j,i);
          q_gas_volume += contribution;
          q_abs_volume += std::abs(contribution);
        }
  }
  const auto flags = std::cout.flags();
  const auto precision = std::cout.precision();
  std::cout << std::scientific << std::setprecision(16)
            << "[MIXED_IMPLICIT_LEDGER] rank=" << Globals::my_rank
            << " cycle=" << pmy_mesh_->ncycle << " time=" << pmy_mesh_->time
            << " stage=" << stage_ << " dt=" << dt_
            << " implicit_q=" << first->implicit_mixed_frame_drift
            << " q_gas_volume=" << q_gas_volume
            << " q_abs_volume=" << q_abs_volume
            << " q_radiation_volume=" << -q_gas_volume
            << " pair_balance_volume=" << q_gas_volume-q_gas_volume
            << std::endl;
  std::cout.flags(flags);
  std::cout.precision(precision);
}

NRFLD::NRFLD(MeshBlock *pmb, ParameterInput *pin) :
    NewtonRaphson(pmb->pmy_mesh->pmnr, pmb, NGHOST,
                  NewtonRaphsonFLD::NNRDIV,
                  NewtonRaphsonFLD::NDCOEFF),
    pmy_driver_(pmb->pmy_mesh->pmnr),
    pmy_block_(pmb),
    u_gas_(pmb->ncells3, pmb->ncells2, pmb->ncells1),
    u_gas_iter_backup_(pmb->ncells3, pmb->ncells2, pmb->ncells1),
    gas_defect_(pmb->ncells3, pmb->ncells2, pmb->ncells1),
    mixed_drift_(6, pmb->ncells3, pmb->ncells2, pmb->ncells1),
    ngh_(NGHOST),
    // The optional per-cell cap can alter the multigrid correction, especially
    // across SMR/AMR interfaces.  AddDifference uses the resulting applied
    // radiation correction in the mixed-frame gas stencil; Newton backtracking
    // still controls acceptance of the complete nonlinear update.
    max_update_fraction_(pin->GetOrAddReal("nrfld", "max_update_fraction", -1.0)),
    backward_error_convergence_(pin->GetOrAddBoolean(
        "nrfld", "backward_error_convergence", false)),
    exact_local_gas_solve_(pin->GetOrAddBoolean(
        "nrfld", "exact_local_gas_solve", false)),
    fixed_linear_coefficients_initialized_(false),
    jacobian_check_(pin->GetOrAddBoolean("nrfld", "jacobian_check", false)),
    jacobian_check_done_(false),
    jacobian_check_epsilon_(pin->GetOrAddReal(
        "nrfld", "jacobian_check_epsilon", 1.0e-4))
    {
    last_delta_rad_.NewAthenaArray(2, pmb->ncells3, pmb->ncells2, pmb->ncells1);
    last_delta_rad_.ZeroClear();
    mixed_drift_.ZeroClear();

    // check pointer
    if (pmy_driver_ == nullptr) {
      std::stringstream msg;
      msg << "### FATAL ERROR in NRFLD::NRFLD" << std::endl
          << "NewtonRaphsonDriver pointer is null" << std::endl;
      ATHENA_ERROR(msg);
    }
    if (pmy_driver_->plmgd_ == nullptr) {
      std::stringstream msg;
      msg << "### FATAL ERROR in NRFLD::NRFLD" << std::endl
          << "linearMGDriver pointer is null" << std::endl;
      ATHENA_ERROR(msg);
    }
    if (!(jacobian_check_epsilon_ > 0.0) ||
        !std::isfinite(jacobian_check_epsilon_)) {
      std::stringstream msg;
      msg << "### FATAL ERROR in NRFLD::NRFLD" << std::endl
          << "nrfld/jacobian_check_epsilon must be finite and positive." << std::endl;
      ATHENA_ERROR(msg);
    }
    if (!std::isfinite(max_update_fraction_)) {
      std::stringstream msg;
      msg << "### FATAL ERROR in NRFLD::NRFLD" << std::endl
          << "nrfld/max_update_fraction must be finite; values <= 0 disable the cap."
          << std::endl;
      ATHENA_ERROR(msg);
    }
    // pmy_mesh(pm),
    // coarse_u_(1, pmb->ncc3, pmb->ncc2, pmb->ncc1,
    //              (pmb->pmy_mesh->multilevel ? AthenaArray<Real>::DataStatus::allocated :
    //               AthenaArray<Real>::DataStatus::empty)), // ? caution!
    // nrbvar(pmb, &u_, &coarse_u_, u_flux_, true),
    // plmg_ = new linearMG(pmy_driver_->plinsolver_->Solve(), pmb, pin);
    if (NRMGFLD_ENABLED) {
      plmg_ = new linearMG(pmy_driver_->plmgd_, pmb, pin, this);
      pmb->plmg = plmg_;
    }
 }


NRFLD::~NRFLD() {
  const bool trace_dtor = (std::getenv("ATHENA_TRACE_DTOR") != nullptr);
  if (NRMGFLD_ENABLED) {
    if (trace_dtor) {
      std::cout << "[DTOR] NRFLD gid=" << pmy_block_->gid
                << " delete plmg_ ptr=" << plmg_
                << " block.plmg=" << pmy_block_->plmg << std::endl;
    }
    delete plmg_;
  }
}


void NRFLD::RunJacobianDiagnostic(Real dt) {
  if (!jacobian_check_ || jacobian_check_done_ || dt == 0.0 || pmy_block_->gid != 0)
    return;
  jacobian_check_done_ = true;

  const int is = pmy_block_->is, ie = pmy_block_->ie;
  const int js = pmy_block_->js, je = pmy_block_->je;
  const int ks = pmy_block_->ks, ke = pmy_block_->ke;
  if (ie-is < 2 || je-js < 2 || ke-ks < 2) {
    if (Globals::my_rank == 0)
      std::cout << "[NRFLD Jacobian] skipped: MeshBlock interior is too small."
                << std::endl;
    return;
  }

  AthenaArray<Real> vr(pmy_block_->ncells3, pmy_block_->ncells2,
                       pmy_block_->ncells1);
  AthenaArray<Real> vg(pmy_block_->ncells3, pmy_block_->ncells2,
                       pmy_block_->ncells1);
  vr.ZeroClear();
  vg.ZeroClear();
  const int ni = ie-is+1, nj = je-js+1, nk = ke-ks+1;
  const int ncells = ni*nj*nk;
  std::vector<Real> fg0(ncells), fr0(ncells), ur0(ncells), ug0(ncells);
  auto index = [=](int k, int j, int i) {
    return ((k-ks)*nj + (j-js))*ni + (i-is);
  };
  for (int k = ks; k <= ke; ++k) {
    for (int j = js; j <= je; ++j) {
      for (int i = is; i <= ie; ++i) {
        const Real phase = 0.173*(i-is+1) + 0.311*(j-js+1) + 0.419*(k-ks+1);
        vr(k,j,i) = std::max(std::abs(u_(k,j,i)), TINY_NUMBER)
                  *(0.5 + 0.25*std::sin(phase));
        vg(k,j,i) = std::max(std::abs(u_gas_(k,j,i)), TINY_NUMBER)
                  *(0.5 + 0.25*std::cos(phase));
        ur0[index(k,j,i)] = u_(k,j,i);
        ug0[index(k,j,i)] = u_gas_(k,j,i);
        fg0[index(k,j,i)] = derivetive_(NewtonRaphsonFLD::Fg,k,j,i);
        fr0[index(k,j,i)] = derivetive_(NewtonRaphsonFLD::Fr,k,j,i);
      }
    }
  }

  const Real dx = pmy_block_->pcoord->dx1f(is);
  const Real fac = dt/SQR(dx);
  for (int pass = 0; pass < 3; ++pass) {
    const Real h = jacobian_check_epsilon_*std::pow(0.1, pass);
    for (int k = ks; k <= ke; ++k)
      for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie; ++i) {
          u_(k,j,i) = ur0[index(k,j,i)] + h*vr(k,j,i);
          u_gas_(k,j,i) = ug0[index(k,j,i)] + h*vg(k,j,i);
        }

    CalculateCoefficients(uold_, u_, def_coeff_, coeff_, derivetive_, src_, dt);
    long double fg_diff2 = 0.0, fg_jv2 = 0.0;
    long double fr_diff2 = 0.0, fr_jv2 = 0.0;
    Real fg_max_rel = 0.0, fr_max_rel = 0.0;
    std::int64_t count = 0;
    // The deterministic perturbation is local to this MeshBlock and does not
    // communicate neighbour-block ghosts, so exclude one cell next to an
    // internal MeshBlock face.  A physical-boundary ghost is prescribed
    // independently of the interior perturbation; include that boundary cell
    // so Robin/Marshak face derivatives are covered by this diagnostic.
    const RegionSize &block = pmy_block_->block_size;
    const RegionSize &mesh = pmy_block_->pmy_mesh->mesh_size;
    const int il = (block.x1min == mesh.x1min) ? is : is+1;
    const int iu = (block.x1max == mesh.x1max) ? ie : ie-1;
    const int jl = (block.x2min == mesh.x2min) ? js : js+1;
    const int ju = (block.x2max == mesh.x2max) ? je : je-1;
    const int kl = (block.x3min == mesh.x3min) ? ks : ks+1;
    const int ku = (block.x3max == mesh.x3max) ? ke : ke-1;
    for (int k = kl; k <= ku; ++k) {
      for (int j = jl; j <= ju; ++j) {
        for (int i = il; i <= iu; ++i) {
          const Real mixed_jv = dt*MixedDriftTerm(mixed_drift_, vr, k,j,i,0.5/dx);
          const Real jvg = derivetive_(NewtonRaphsonFLD::dFg_deg,k,j,i)*vg(k,j,i)
                         + derivetive_(NewtonRaphsonFLD::dFg_dEr,k,j,i)*vr(k,j,i)
                         - mixed_jv;
          Real jvr = derivetive_(NewtonRaphsonFLD::dFr_deg,k,j,i)*vg(k,j,i)
                   + derivetive_(NewtonRaphsonFLD::dFr_dEr,k,j,i)*vr(k,j,i)
                   + mixed_jv;
          jvr += fac*coeff_(linearSolver::DXMF,k,j,i)*vr(k,j,i-1);
          jvr += fac*coeff_(linearSolver::DXPF,k,j,i)*vr(k,j,i+1);
          jvr += fac*coeff_(linearSolver::DYMF,k,j,i)*vr(k,j-1,i);
          jvr += fac*coeff_(linearSolver::DYPF,k,j,i)*vr(k,j+1,i);
          jvr += fac*coeff_(linearSolver::DZMF,k,j,i)*vr(k-1,j,i);
          jvr += fac*coeff_(linearSolver::DZPF,k,j,i)*vr(k+1,j,i);
          const Real fdg = (derivetive_(NewtonRaphsonFLD::Fg,k,j,i)
                           - fg0[index(k,j,i)])/h;
          const Real fdr = (derivetive_(NewtonRaphsonFLD::Fr,k,j,i)
                           - fr0[index(k,j,i)])/h;
          const Real dg = fdg-jvg, dr = fdr-jvr;
          fg_diff2 += static_cast<long double>(dg)*dg;
          fg_jv2 += static_cast<long double>(jvg)*jvg;
          fr_diff2 += static_cast<long double>(dr)*dr;
          fr_jv2 += static_cast<long double>(jvr)*jvr;
          fg_max_rel = std::max(fg_max_rel,
              std::abs(dg)/std::max({std::abs(fdg), std::abs(jvg), TINY_NUMBER}));
          fr_max_rel = std::max(fr_max_rel,
              std::abs(dr)/std::max({std::abs(fdr), std::abs(jvr), TINY_NUMBER}));
          ++count;
        }
      }
    }
    std::cout << "[NRFLD Jacobian] gid=" << pmy_block_->gid
              << " epsilon=" << h << " cells=" << count
              << " gas_l2_rel="
              << std::sqrt(static_cast<Real>(fg_diff2/std::max(fg_jv2, 1.0e-300L)))
              << " gas_max_rel=" << fg_max_rel
              << " radiation_l2_rel="
              << std::sqrt(static_cast<Real>(fr_diff2/std::max(fr_jv2, 1.0e-300L)))
              << " radiation_max_rel=" << fr_max_rel << std::endl;

    for (int k = ks; k <= ke; ++k)
      for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie; ++i) {
          u_(k,j,i) = ur0[index(k,j,i)];
          u_gas_(k,j,i) = ug0[index(k,j,i)];
        }
    CalculateCoefficients(uold_, u_, def_coeff_, coeff_, derivetive_, src_, dt);
  }
}

void NRFLD::LoadVariables() {
  FLD *pfld = pmy_block_->prfld;
  fixed_linear_coefficients_initialized_ = false;
  pfld->LoadHydroVariables(pmy_block_->phydro->w,
                          pmy_block_->phydro->u, pfld->u_gas);
  if (last_delta_rad_.data() == nullptr) {
    std::stringstream msg;
    msg << "### FATAL ERROR in NRFLD::LoadVariables" << std::endl
        << "Debug delta array is not allocated."
        << " ptr=" << static_cast<const void*>(last_delta_rad_.data())
        << " dims=(" << last_delta_rad_.GetDim4() << ","
        << last_delta_rad_.GetDim3() << ","
        << last_delta_rad_.GetDim2() << ","
        << last_delta_rad_.GetDim1() << ")" << std::endl;
    ATHENA_ERROR(msg);
  }
  int il = pmy_block_->is - NGHOST, iu = pmy_block_->ie + NGHOST;
  int jl = pmy_block_->js, ju = pmy_block_->je;
  int kl = pmy_block_->ks, ku = pmy_block_->ke;
  if (pmy_block_->pmy_mesh->f2)
    jl -= NGHOST, ju += NGHOST;
  if (pmy_block_->pmy_mesh->f3)
    kl -= NGHOST, ku += NGHOST;
  for (int k = kl; k <= ku; ++k) {
    for (int j = jl; j <= ju; ++j) {
      for (int i = il; i <= iu; ++i) {
        u_gas_(k,j,i) = pfld->u_gas(k,j,i);
        u_(k,j,i) = pfld->u_rad(k,j,i);
        uold_(k,j,i) = pfld->u_rad(k,j,i);
        last_delta_rad_(0,k,j,i) = 0.0;
        last_delta_rad_(1,k,j,i) = 0.0;

      }
    }
  }
  return;
}

void NRFLD::UpdateHydroVariables() {
  FLD *pfld = pmy_block_->prfld;
  pfld->UpdateHydroVariables(pmy_block_->phydro->w,
                             pmy_block_->phydro->u,
                             u_, u_gas_);
  return;
}

void NRFLD::StoreIterate() {
  NewtonRaphson::StoreIterate();
  u_gas_iter_backup_ = u_gas_;
  user_diagnostic_counters_iter_backup_ =
      pmy_block_->prfld->user_diagnostic_counters;
}

void NRFLD::RestoreIterate() {
  NewtonRaphson::RestoreIterate();
  u_gas_ = u_gas_iter_backup_;
  pmy_block_->prfld->user_diagnostic_counters =
      user_diagnostic_counters_iter_backup_;
}

void NRFLD::CalculateCoefficientsOnce(const AthenaArray<Real> &u_pre,
                                      const AthenaArray<Real> &w,
                                      AthenaArray<Real> &def_coeff,
                                      AthenaArray<Real> &derivetive) {
  FLD *pfld = pmy_block_->prfld;
  const AthenaArray<Real> &sigma_r = pfld->sigma_r;
  int is = pmy_block_->is, ie = pmy_block_->ie;
  int js = pmy_block_->js, je = pmy_block_->je;
  int ks = pmy_block_->ks, ke = pmy_block_->ke;
  Real dx = pmy_block_->pcoord->dx1f(is);
  Real dy = pmy_block_->pcoord->dx2f(js);
  Real dz = pmy_block_->pcoord->dx3f(ks);
  Real idx = 1.0/dx;
  Real idy = 1.0/dy;
  Real idz = 1.0/dz;
  const bool mixed_active = pfld->MixedFrameCoupled()
      && pfld->implicit_mixed_frame_drift;
  const int check_il = std::max(0, is-1);
  const int check_iu = std::min(u_pre.GetDim1()-1, ie+1);
  const int check_jl = std::max(0, js-1);
  const int check_ju = std::min(u_pre.GetDim2()-1, je+1);
  const int check_kl = std::max(0, ks-1);
  const int check_ku = std::min(u_pre.GetDim3()-1, ke+1);
  for (int k=check_kl; k<=check_ku; ++k) {
    for (int j=check_jl; j<=check_ju; ++j) {
      for (int i=check_il; i<=check_iu; ++i) {
        if (!std::isfinite(u_pre(k,j,i)) || u_pre(k,j,i) < 0.0) {
          std::stringstream msg;
          msg << "### FATAL ERROR in NR-FLD radiation energy" << std::endl
              << "Er at (k,j,i)=(" << k << "," << j << "," << i << ") is "
              << u_pre(k,j,i)
              << "; radiation energy must be finite and non-negative.\n";
          ATHENA_ERROR(msg);
        }
      }
    }
  }
  for (int k=ks; k<=ke; k++) {
    for (int j=js; j<=je; j++) {
      // The lower x-face reuses the upper face from i-1 below.  This loop has
      // a genuine loop-carried dependency and must not be declared SIMD.
      for (int i=is; i<=ie; i++) {
        def_coeff(NewtonRaphsonFLD::DRHO,k,j,i) = w(IDN,k,j,i);
        // for derivetive of temperature to gas energy
#if GENERAL_EOS
        Real rho = w(IDN,k,j,i);
        Real egas = u_gas_(k,j,i);
        Real temperature = pmy_block_->peos->TempFromRhoEg(rho, egas);
        Real dlnT_dlnE = pmy_block_->peos->DlnTDlnEgasFromRhoEg(rho, egas);
        def_coeff(NewtonRaphsonFLD::DCOUPLE,k,j,i) = temperature/egas * dlnT_dlnE;
#else
        Real gm1 = pmy_block_->peos->GetGamma() - 1.0;
        def_coeff(NewtonRaphsonFLD::DCOUPLE,k,j,i) = gm1/w(IDN,k,j,i);
#endif

        // for lambda and coefficient of diff term
        // not to use loop for better performance
        // compute derivetive at faces and store in derivetive array

        Real sigma_rface;
        Real gx, gy, gz, gradE_face, E_face;

        // The + face of the previous active cell is exactly the - face of
        // this cell.  Reuse it in block interiors; only the lower block face
        // needs a separate stencil evaluation.
        if (i == is) {
          // for i-1/2 face
          sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j,i-1), idx);
          gx = (u_pre(k,j,i-1) - u_pre(k,j,i))*idx;
          gy = 0.25*idy*((u_pre(k,j+1,i-1) - u_pre(k,j-1,i-1)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
          gz = 0.25*idz*((u_pre(k+1,j,i-1) - u_pre(k-1,j,i-1)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
          gradE_face = FaceGradient(gx, gy, gz);
          E_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j,i-1));
          const RadFLD::ClosureValues closure = RequireFaceClosure(
              gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
              "x-", k, j, i);
          derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i) =
              pfld->c_ph*closure.lambda_over_opacity;
          mixed_drift_(XMinus,k,j,i) = mixed_active ? MixedDriftFace(
              closure, pfld->sigma_p(k,j,i-1), pfld->sigma_p(k,j,i),
              w(IVX,k,j,i-1), w(IVX,k,j,i)) : 0.0;
        } else {
          derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i) =
              derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i-1);
          mixed_drift_(XMinus,k,j,i) = mixed_drift_(XPlus,k,j,i-1);
        }

         // for i+1/2 face
        sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j,i+1), idx);
        gx = (u_pre(k,j,i+1) - u_pre(k,j,i))*idx;
        gy = 0.25*idy*((u_pre(k,j+1,i+1) - u_pre(k,j-1,i+1)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
        gz = 0.25*idz*((u_pre(k+1,j,i+1) - u_pre(k-1,j,i+1)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
        gradE_face = FaceGradient(gx, gy, gz);
        E_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j,i+1));
        const RadFLD::ClosureValues closure_xp = RequireFaceClosure(
            gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
            "x+", k, j, i);
        derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i) =
            pfld->c_ph*closure_xp.lambda_over_opacity;
        mixed_drift_(XPlus,k,j,i) = mixed_active ? MixedDriftFace(
            closure_xp, pfld->sigma_p(k,j,i), pfld->sigma_p(k,j,i+1),
            w(IVX,k,j,i), w(IVX,k,j,i+1)) : 0.0;

        if (j == js) {
          // for j-1/2 face
          sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j-1,i), idx);
          gx = 0.25*idx*((u_pre(k,j-1,i+1) - u_pre(k,j-1,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
          gy = (u_pre(k,j-1,i) - u_pre(k,j,i))*idy;
          gz = 0.25*idz*((u_pre(k+1,j-1,i) - u_pre(k-1,j-1,i)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
          gradE_face = FaceGradient(gx, gy, gz);
          E_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j-1,i));
          const RadFLD::ClosureValues closure_ym = RequireFaceClosure(
              gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
              "y-", k, j, i);
          derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i) =
              pfld->c_ph*closure_ym.lambda_over_opacity;
          mixed_drift_(YMinus,k,j,i) = mixed_active && pmy_block_->block_size.nx2 > 1
              ? MixedDriftFace(closure_ym, pfld->sigma_p(k,j-1,i),
                               pfld->sigma_p(k,j,i), w(IVY,k,j-1,i),
                               w(IVY,k,j,i)) : 0.0;
        } else {
          derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i) =
              derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j-1,i);
          mixed_drift_(YMinus,k,j,i) = mixed_drift_(YPlus,k,j-1,i);
        }

        // for j+1/2 face
        sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j+1,i), idx);
        gx = 0.25*idx*((u_pre(k,j+1,i+1) - u_pre(k,j+1,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
        gy = (u_pre(k,j+1,i) - u_pre(k,j,i))*idy;
        gz = 0.25*idz*((u_pre(k+1,j+1,i) - u_pre(k-1,j+1,i)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
        gradE_face = FaceGradient(gx, gy, gz);
        E_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j+1,i));
        const RadFLD::ClosureValues closure_yp = RequireFaceClosure(
            gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
            "y+", k, j, i);
        derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j,i) =
            pfld->c_ph*closure_yp.lambda_over_opacity;
        mixed_drift_(YPlus,k,j,i) = mixed_active && pmy_block_->block_size.nx2 > 1
            ? MixedDriftFace(closure_yp, pfld->sigma_p(k,j,i),
                             pfld->sigma_p(k,j+1,i), w(IVY,k,j,i),
                             w(IVY,k,j+1,i)) : 0.0;

        if (k == ks) {
          // for k-1/2 face
          sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k-1,j,i), idx);
          gx = 0.25*idx*((u_pre(k-1,j,i+1) - u_pre(k-1,j,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
          gy = 0.25*idy*((u_pre(k-1,j+1,i) - u_pre(k-1,j-1,i)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
          gz = (u_pre(k-1,j,i) - u_pre(k,j,i))*idz;
          gradE_face = FaceGradient(gx, gy, gz);
          E_face = FaceEnergy(u_pre(k,j,i), u_pre(k-1,j,i));
          const RadFLD::ClosureValues closure_zm = RequireFaceClosure(
              gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
              "z-", k, j, i);
          derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i) =
              pfld->c_ph*closure_zm.lambda_over_opacity;
          mixed_drift_(ZMinus,k,j,i) = mixed_active && pmy_block_->block_size.nx3 > 1
              ? MixedDriftFace(closure_zm, pfld->sigma_p(k-1,j,i),
                               pfld->sigma_p(k,j,i), w(IVZ,k-1,j,i),
                               w(IVZ,k,j,i)) : 0.0;
        } else {
          derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i) =
              derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k-1,j,i);
          mixed_drift_(ZMinus,k,j,i) = mixed_drift_(ZPlus,k-1,j,i);
        }

        // for k+1/2 face
        sigma_rface = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k+1,j,i), idx);
        gx = 0.25*idx*((u_pre(k+1,j,i+1) - u_pre(k+1,j,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
        gy = 0.25*idy*((u_pre(k+1,j+1,i) - u_pre(k+1,j-1,i)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
        gz = (u_pre(k+1,j,i) - u_pre(k,j,i))*idz;
        gradE_face = FaceGradient(gx, gy, gz);
        E_face = FaceEnergy(u_pre(k,j,i), u_pre(k+1,j,i));
        const RadFLD::ClosureValues closure_zp = RequireFaceClosure(
            gradE_face, sigma_rface, E_face, pfld->fixed_flux_limiter,
            "z+", k, j, i);
        derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i) =
            pfld->c_ph*closure_zp.lambda_over_opacity;
        mixed_drift_(ZPlus,k,j,i) = mixed_active && pmy_block_->block_size.nx3 > 1
            ? MixedDriftFace(closure_zp, pfld->sigma_p(k,j,i),
                             pfld->sigma_p(k+1,j,i), w(IVZ,k,j,i),
                             w(IVZ,k+1,j,i)) : 0.0;
        // Preserve every lagged face diffusion coefficient used by this
        // Newton solve.  A face-flux boundary must use the same D in its
        // residual and Jacobian as the interior discretization.
        pfld->marshak_dface_all(XMinus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i);
        pfld->marshak_dface_all(XPlus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i);
        pfld->marshak_dface_all(YMinus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i);
        pfld->marshak_dface_all(YPlus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j,i);
        pfld->marshak_dface_all(ZMinus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i);
        pfld->marshak_dface_all(ZPlus,k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i);
        // Legacy top-only storage for existing diagnostics.
        pfld->marshak_dface(k,j,i) =
            derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i);

      }
    }
  }

  if (pfld->cut_diff) {
    for (int k=ks; k<=ke; k++) {
      for (int j=js; j<=je; j++) {
        for (int i=is; i<=ie; i++) {
          for (int n = 0; n < 6; n++) {
            derivetive(NewtonRaphsonFLD::dFr_dEr_xm+n,k,j,i) = 0.0;
          }
          pfld->marshak_dface(k,j,i) = 0.0;
        }
      }
    }
  }
}

void NRFLD::CalculateCoefficients(const AthenaArray<Real> &u_rad_old,
                                  const AthenaArray<Real> &u_rad_new,
                                  // const AthenaArray<Real> &u_gas_old,
                                  // const AthenaArray<Real> &u_gas_new,
                                  const AthenaArray<Real> &def_coeff,
                                  AthenaArray<Real> &coeff,
                                  AthenaArray<Real> &derivetive,
                                  AthenaArray<Real> &src,
                                  Real dt) {
  FLD *pfld = pmy_block_->prfld;
  AthenaArray<Real> &u_gas_new = u_gas_; // caution! this should be in argument
  AthenaArray<Real> &u_gas_old = pfld->u_gas; // caution! this should be in argument

  int is = pmy_block_->is, ie = pmy_block_->ie;
  int js = pmy_block_->js, je = pmy_block_->je;
  int ks = pmy_block_->ks, ke = pmy_block_->ke;
  Real dx = pmy_block_->pcoord->dx1f(is);
  Real idx2 = 1.0/(dx*dx);
  for (int k=ks; k<=ke; k++) {
    for (int j=js; j<=je; j++) {
#pragma omp simd
      for (int i=is; i<=ie; i++) {
        Real c_sigma_p = pfld->c_ph*pfld->sigma_p(k,j,i);

        Real sum_dcp = 0.0;
        if (fixed_linear_coefficients_initialized_) {
          sum_dcp = coeff(linearSolver::DCCF,k,j,i);
        } else {
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i);
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i);
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i);
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j,i);
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i);
          sum_dcp += derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i);
        }

        Real T_gas_new;
#if GENERAL_EOS
        T_gas_new = pmy_block_->peos->TempFromRhoEg(def_coeff(NewtonRaphsonFLD::DRHO,k,j,i), u_gas_new(k,j,i));
#else
        T_gas_new = def_coeff(NewtonRaphsonFLD::DCOUPLE,k,j,i)*u_gas_new(k,j,i);
#endif
        const Real T_gas_new2 = T_gas_new*T_gas_new;
        const Real T_gas_new3 = T_gas_new2*T_gas_new;
        const Real T_gas_new4 = T_gas_new2*T_gas_new2;
        const Real equilibrium_rad = pfld->a_r*T_gas_new4;
        Real src_term = c_sigma_p*ResolvableThermalDifference(
            equilibrium_rad, u_rad_new(k,j,i));
        const Real center = u_rad_new(k,j,i);
        const Real face_coeff[6] = {
          derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i),
          derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i),
          derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i),
          derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j,i),
          derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i),
          derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i)};
        const Real neighbor[6] = {u_rad_new(k,j,i-1), u_rad_new(k,j,i+1),
          u_rad_new(k,j-1,i), u_rad_new(k,j+1,i),
          u_rad_new(k-1,j,i), u_rad_new(k+1,j,i)};
        bool marshak[6];
        Real marshak_dflux_sum = 0.0;
        Real diff_term = 0.0;
        for (int face=0; face<6; ++face) {
          marshak[face] = MarshakFaceActive(pmy_block_, pfld, face,k,j,i);
          if (marshak[face]) {
            Real derivative = 0.0;
            diff_term -= MarshakFlux(pfld, face,k,j,i,center,dx,&derivative)*dx;
            marshak_dflux_sum += derivative;
          } else {
            diff_term += face_coeff[face]*(neighbor[face] - center);
          }
        }
        diff_term *= idx2;

        const Real mixed_term = MixedDriftTerm(
            mixed_drift_, u_rad_new, k,j,i,0.5*std::sqrt(idx2));

        // The Lorentz correction has equal and opposite gas/radiation signs.
        derivetive(NewtonRaphsonFLD::Fg,k,j,i) =
            (u_gas_new(k,j,i) - u_gas_old(k,j,i))
            + dt*(src_term - mixed_term);
        derivetive(NewtonRaphsonFLD::Fr,k,j,i) = (u_rad_new(k,j,i) - u_rad_old(k,j,i))
            - dt*(src_term + diff_term - mixed_term);

        Real dT_deg = def_coeff(NewtonRaphsonFLD::DCOUPLE,k,j,i);
#if GENERAL_EOS
        // The residual evaluates T at the current Newton iterate.  Its
        // derivative must use that same state: a tabulated EOS does not have
        // the constant dT/deg of an ideal gas.  DCOUPLE was populated only at
        // the beginning of the hydro step and can be stale after cooling or
        // crossing an ionization/table interval.
        dT_deg = T_gas_new/u_gas_new(k,j,i)
            *pmy_block_->peos->DlnTDlnEgasFromRhoEg(
                def_coeff(NewtonRaphsonFLD::DRHO,k,j,i), u_gas_new(k,j,i));
#endif
        const Real exchange_jacobian = 4.0*dt*c_sigma_p*pfld->a_r*T_gas_new3
            *dT_deg;
        derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i) = 1.0 + exchange_jacobian;
        derivetive(NewtonRaphsonFLD::dFg_dEr,k,j,i) = -dt*c_sigma_p;
        derivetive(NewtonRaphsonFLD::dFr_deg,k,j,i) = -exchange_jacobian;
        Real boundary_coeff = sum_dcp;
        if (!fixed_linear_coefficients_initialized_) {
          for (int face=0; face<6; ++face)
            if (marshak[face]) boundary_coeff -= face_coeff[face];
        }
        derivetive(NewtonRaphsonFLD::dFr_dEr,k,j,i) =
            1.0 + dt*(c_sigma_p + idx2*(boundary_coeff
                + dx*marshak_dflux_sum));


        if (pfld->fixed_u_rad) {
          // Erad is prescribed rather than an NR unknown.  Leave the linear
          // correction at zero; AddDifference performs the local Newton update
          // of egas with delta_Erad = 0.
          coeff(linearSolver::DCCF,k,j,i) = 0.0;
          coeff(linearSolver::DCCS,k,j,i) = 1.0;
          coeff(linearSolver::DXMF,k,j,i) = 0.0;
          coeff(linearSolver::DXPF,k,j,i) = 0.0;
          coeff(linearSolver::DYMF,k,j,i) = 0.0;
          coeff(linearSolver::DYPF,k,j,i) = 0.0;
          coeff(linearSolver::DZMF,k,j,i) = 0.0;
          coeff(linearSolver::DZPF,k,j,i) = 0.0;
          coeff(linearSolver::DXMS,k,j,i) = 0.0;
          coeff(linearSolver::DXPS,k,j,i) = 0.0;
          coeff(linearSolver::DYMS,k,j,i) = 0.0;
          coeff(linearSolver::DYPS,k,j,i) = 0.0;
          coeff(linearSolver::DZMS,k,j,i) = 0.0;
          coeff(linearSolver::DZPS,k,j,i) = 0.0;
          src(k,j,i) = 0.0;
        } else {
          if (!fixed_linear_coefficients_initialized_) {
            coeff(linearSolver::DCCF,k,j,i) = boundary_coeff;
            coeff(linearSolver::DXMF,k,j,i) = marshak[XMinus] ? 0.0 : -face_coeff[XMinus];
            coeff(linearSolver::DXPF,k,j,i) = marshak[XPlus]  ? 0.0 : -face_coeff[XPlus];
            coeff(linearSolver::DYMF,k,j,i) = marshak[YMinus] ? 0.0 : -face_coeff[YMinus];
            coeff(linearSolver::DYPF,k,j,i) = marshak[YPlus]  ? 0.0 : -face_coeff[YPlus];
            coeff(linearSolver::DZMF,k,j,i) = marshak[ZMinus] ? 0.0 : -face_coeff[ZMinus];
            coeff(linearSolver::DZPF,k,j,i) = marshak[ZPlus]  ? 0.0 : -face_coeff[ZPlus];
          }
          // Eliminate the gas-energy correction from the two-equation
          // Newton system.  Since thermal exchange enters the gas and
          // radiation equations with equal and opposite signs,
          //
          //   dFr/deg = 1 - dFg/deg
          //
          // for the local (non-diffusive) terms.  Writing the resulting
          // Schur complement directly as
          //
          //   (1 + C) - B*C/(1 + B)
          //
          // loses all useful digits when the matter-radiation coupling is
          // very stiff (B,C >> 1).  In the static-equilibrium test C can be
          // O(1e20), which previously produced spurious values such as
          // -65536, -256, or zero for this positive diagonal.  Use the
          // algebraically identical forms
          //
          //   1 - (dFg/dEr)/(dFg/deg)
          //   -Ftotal + Fg/(dFg/deg)
          //
          // for the local diagonal and reduced right-hand side.  These also
          // preserve the exact cancellation of equal-and-opposite exchange
          // residuals without adding two O(C) terms.  Form Ftotal directly:
          // separately rounded Fg and Fr lose the small total when exchange
          // is stiff (WOR-26).
          const Real inv_dFg_deg =
              1.0/derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i);
          // The face drift has a center contribution when its two face
          // coefficients differ.  Keep it in the unscaled diagonal slot.
          const Real drift_fac = 0.5*dt*std::sqrt(idx2)*inv_dFg_deg;
          const Real drift_center = drift_fac*(
              mixed_drift_(XMinus,k,j,i)-mixed_drift_(XPlus,k,j,i)
            + mixed_drift_(YMinus,k,j,i)-mixed_drift_(YPlus,k,j,i)
            + mixed_drift_(ZMinus,k,j,i)-mixed_drift_(ZPlus,k,j,i));
          coeff(linearSolver::DCCS,k,j,i) =
              1.0 - derivetive(NewtonRaphsonFLD::dFg_dEr,k,j,i)*inv_dFg_deg
              + drift_center
              // The Robin boundary is a local face-reaction term in the
              // matrix, dt*(dF/dE)/dx.  Keep it in DCCS rather than DCCF:
              // DCCF is rescaled by dt/dx^2 at every MG level, which would
              // otherwise discard or incorrectly scale the boundary term
              // during coefficient restriction.
              + dt*marshak_dflux_sum/dx;
          // Elimination of the local gas correction leaves a directed,
          // nonsymmetric nearest-neighbour term in the radiation matrix.
          // The *S slots are not multiplied by dt/dx^2 by linearMG.
          coeff(linearSolver::DXMS,k,j,i) = -drift_fac*mixed_drift_(XMinus,k,j,i);
          coeff(linearSolver::DXPS,k,j,i) =  drift_fac*mixed_drift_(XPlus,k,j,i);
          coeff(linearSolver::DYMS,k,j,i) = -drift_fac*mixed_drift_(YMinus,k,j,i);
          coeff(linearSolver::DYPS,k,j,i) =  drift_fac*mixed_drift_(YPlus,k,j,i);
          coeff(linearSolver::DZMS,k,j,i) = -drift_fac*mixed_drift_(ZMinus,k,j,i);
          coeff(linearSolver::DZPS,k,j,i) =  drift_fac*mixed_drift_(ZPlus,k,j,i);
          const Real total_residual =
              (u_gas_new(k,j,i) - u_gas_old(k,j,i))
              + (u_rad_new(k,j,i) - u_rad_old(k,j,i)) - dt*diff_term;
          src(k,j,i) = -total_residual
              + derivetive(NewtonRaphsonFLD::Fg,k,j,i)*inv_dFg_deg;
        }

      }
    }
  }
  // Opt-in audit of cancellation in the coupled Schur right-hand side.  The
  // direct total omits the equal-and-opposite thermal and mixed-frame terms.
  // Keep this separate from the vectorized production loop.
  if (std::getenv("ATHENA_NRFLD_SCHUR_AUDIT") != nullptr &&
      !pfld->only_rad && !pfld->fixed_u_rad) {
    Real worst_ratio = -1.0, worst_abs = 0.0, worst_scale = 0.0;
    Real worst_total_scale = 0.0, max_total_ratio = 0.0;
    int total_i = is, total_j = js, total_k = ks;
    Real worst_naive = 0.0, worst_direct = 0.0, worst_exchange = 0.0;
    Real worst_rhs = 0.0, worst_rhs_direct = 0.0, worst_rhs_legacy = 0.0;
    int worst_i = is, worst_j = js, worst_k = ks;
    for (int k=ks; k<=ke; ++k) {
      for (int j=js; j<=je; ++j) {
        for (int i=is; i<=ie; ++i) {
          const Real center = u_rad_new(k,j,i);
          const Real face_coeff[6] = {
            derivetive(NewtonRaphsonFLD::dFr_dEr_xm,k,j,i),
            derivetive(NewtonRaphsonFLD::dFr_dEr_xp,k,j,i),
            derivetive(NewtonRaphsonFLD::dFr_dEr_ym,k,j,i),
            derivetive(NewtonRaphsonFLD::dFr_dEr_yp,k,j,i),
            derivetive(NewtonRaphsonFLD::dFr_dEr_zm,k,j,i),
            derivetive(NewtonRaphsonFLD::dFr_dEr_zp,k,j,i)};
          const Real neighbor[6] = {u_rad_new(k,j,i-1), u_rad_new(k,j,i+1),
            u_rad_new(k,j-1,i), u_rad_new(k,j+1,i),
            u_rad_new(k-1,j,i), u_rad_new(k+1,j,i)};
          Real diff_term = 0.0;
          Real diff_abs_term = 0.0;
          for (int face=0; face<6; ++face) {
            Real face_term;
            if (MarshakFaceActive(pmy_block_, pfld, face,k,j,i)) {
              face_term = -MarshakFlux(pfld, face,k,j,i,center,dx,nullptr)*dx;
            } else {
              face_term = face_coeff[face]*(neighbor[face] - center);
            }
            diff_term += face_term;
            diff_abs_term += std::abs(face_term);
          }
          diff_term *= idx2;
          diff_abs_term *= idx2;
          const Real gas_delta = u_gas_new(k,j,i) - u_gas_old(k,j,i);
          const Real rad_delta = center - u_rad_old(k,j,i);
          const Real direct = (gas_delta + rad_delta) - dt*diff_term;
          const Real fg = derivetive(NewtonRaphsonFLD::Fg,k,j,i);
          const Real fr = derivetive(NewtonRaphsonFLD::Fr,k,j,i);
          const Real naive = fg + fr;
          const Real abs_delta = std::abs(naive - direct);
          const Real scale = std::max({std::abs(gas_delta), std::abs(rad_delta),
              std::abs(dt*diff_term), std::abs(u_gas_old(k,j,i)),
              std::abs(u_rad_old(k,j,i)), Real(1.e-30)});
          const Real ratio = abs_delta/scale;
          const Real diffusion_scale = backward_error_convergence_
              ? diff_abs_term : std::abs(diff_term);
          Real total_scale = std::abs(gas_delta) + std::abs(rad_delta)
              + dt*diffusion_scale;
          total_scale = std::max(total_scale,
              std::max(std::abs(u_gas_new(k,j,i) + center),
                       std::abs(u_gas_old(k,j,i) + u_rad_old(k,j,i))));
          total_scale = std::max(total_scale, Real(1.e-30));
          const Real total_ratio = abs_delta/total_scale;
          if (total_ratio > max_total_ratio) {
            max_total_ratio = total_ratio;
            total_i = i; total_j = j; total_k = k;
          }
          if (ratio > worst_ratio) {
            worst_ratio = ratio;
            worst_abs = abs_delta;
            worst_scale = scale;
            worst_total_scale = total_scale;
            worst_naive = naive;
            worst_direct = direct;
            worst_exchange = std::max(std::abs(fg), std::abs(fr));
            const Real gas_schur = fg/derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i);
            worst_rhs = src(k,j,i);
            worst_rhs_direct = -direct + gas_schur;
            worst_rhs_legacy = -naive + gas_schur;
            worst_i = i; worst_j = j; worst_k = k;
          }
        }
      }
    }
    std::cout << std::setprecision(17)
              << "[NR_SCHUR_AUDIT] cycle=" << pmy_block_->pmy_mesh->ncycle
              << " gid=" << pmy_block_->gid << " dt=" << dt
              << " i=" << worst_i << " j=" << worst_j << " k=" << worst_k
              << " naive=" << worst_naive << " direct=" << worst_direct
              << " abs_delta=" << worst_abs << " energy_scale=" << worst_scale
              << " relative_delta=" << worst_ratio
              << " total_scale=" << worst_total_scale
              << " relative_total_delta=" << worst_abs/worst_total_scale
              << " max_relative_total_delta=" << max_total_ratio
              << " total_i=" << total_i << " total_j=" << total_j
              << " total_k=" << total_k
              << " exchange_residual=" << worst_exchange
              << " rhs=" << worst_rhs << " rhs_direct=" << worst_rhs_direct
              << " rhs_legacy=" << worst_rhs_legacy << std::endl;
  }
  fixed_linear_coefficients_initialized_ = true;
}

void NRFLD::CalculateDefect(AthenaArray<Real> &def, const AthenaArray<Real> &u,
              const AthenaArray<Real> &u_old,
              const AthenaArray<Real> &coeff,
              const AthenaArray<Real> &def_coeff,
              bool th) {
  AthenaArray<Real> &u_gas = u_gas_; // caution! this should be in argument
  FLD *pfld = pmy_block_->prfld;
  MeshBlock *pmb = pmy_block_;
  int il = pmb->is, iu = pmb->ie;
  int jl = pmb->js, ju = pmb->je;
  int kl = pmb->ks, ku = pmb->ke;
  Real dx = pmb->pcoord->dx1f(il);
  Real idx2 = 1.0/SQR(dx);
  Real dt = pmy_driver_->dt_;

#pragma omp parallel for num_threads(pmy_driver_->nthreads_) if (th && (ku-kl) >= minth_)
  for (int k=kl; k<=ku; k++) {
    for (int j=jl; j<=ju; j++) {
#pragma omp simd
      for (int i=il; i<=iu; i++) {
        Real T_gas;
#if GENERAL_EOS
        T_gas = pmy_block_->peos->TempFromRhoEg(def_coeff(NewtonRaphsonFLD::DRHO,k,j,i), u_gas(k,j,i));
#else
        T_gas = def_coeff(NewtonRaphsonFLD::DCOUPLE,k,j,i)*u_gas(k,j,i);
#endif
        const Real T_gas2 = T_gas*T_gas;
        const Real equilibrium_rad = pfld->a_r*T_gas2*T_gas2;
        Real src_term = pfld->c_ph*pfld->sigma_p(k,j,i)
            *ResolvableThermalDifference(equilibrium_rad, u(k,j,i));
        const Real center = u(k,j,i);
        const Real matrix_face[6] = {
          -coeff(linearSolver::DXMF,k,j,i), -coeff(linearSolver::DXPF,k,j,i),
          -coeff(linearSolver::DYMF,k,j,i), -coeff(linearSolver::DYPF,k,j,i),
          -coeff(linearSolver::DZMF,k,j,i), -coeff(linearSolver::DZPF,k,j,i)};
        const Real neighbor[6] = {u(k,j,i-1), u(k,j,i+1),
          u(k,j-1,i), u(k,j+1,i), u(k-1,j,i), u(k+1,j,i)};
        Real diff_term = 0.0;
        Real diff_abs_term = 0.0;
        for (int face=0; face<6; ++face) {
          Real face_term;
          if (MarshakFaceActive(pmb,pfld,face,k,j,i)) {
            face_term = -MarshakFlux(
                pfld,face,k,j,i,center,dx,nullptr)*dx;
          } else {
            face_term = matrix_face[face]*(neighbor[face]-center);
          }
          diff_term += face_term;
          diff_abs_term += std::abs(face_term);
        }
        diff_term *= idx2;
        diff_abs_term *= idx2;
        const Real mixed_term = MixedDriftTerm(
            mixed_drift_, u, k,j,i,0.5/std::max(dx, TINY_NUMBER));

        Real Fg = (u_gas(k,j,i) - pfld->u_gas(k,j,i))
                + dt*(src_term - mixed_term);
        Real Fr = (u(k,j,i)     - u_old(k,j,i))
            - dt*(src_term + diff_term - mixed_term);
        // Normalize each equation by its local transient/source scale, with
        // the current and old state as a floor.  This makes gas and radiation
        // residuals dimensionless without letting a nearly-zero update hide
        // an absolute residual near a floor.
        Real unsteady = u(k,j,i) - u_old(k,j,i);
        // A converged diffusion row can be the cancellation of individually
        // large face fluxes.  Scaling by only |sum(face terms)| then reports a
        // false O(1e-3) residual after the state update has reached its last
        // representable bit.  For backward-error convergence use the absolute
        // row sum, which asks whether a tiny perturbation of the assembled
        // discrete equation would make the current state exact.  Retain the
        // legacy net-divergence scale when backward-error control is disabled.
        const Real diffusion_scale = backward_error_convergence_
            ? diff_abs_term : std::abs(diff_term);
        Real scale = std::abs(unsteady)
                   + dt*(std::abs(src_term) + diffusion_scale
                         + std::abs(mixed_term));
        scale = std::max(scale, std::max(std::abs(u(k,j,i)), std::abs(u_old(k,j,i))));
        scale = std::max(scale, static_cast<Real>(1.0e-30));
        Real gas_scale = std::abs(u_gas(k,j,i) - pfld->u_gas(k,j,i))
                       + dt*(std::abs(src_term) + std::abs(mixed_term));
        gas_scale = std::max(gas_scale,
                             std::max(std::abs(u_gas(k,j,i)),
                                      std::abs(pfld->u_gas(k,j,i))));
        gas_scale = std::max(gas_scale, static_cast<Real>(1.0e-30));
        const Real normalized_gas_residual = Fg/gas_scale;
        gas_defect_(k,j,i) = normalized_gas_residual;
        if (backward_error_convergence_) {
          // In the stiff LTE limit, adjacent floating-point states can straddle
          // Fg=0 while both normalized residuals remain much larger than the
          // requested tolerance.  The Newton backward error measures the state
          // perturbation needed to solve the local equation and remains
          // meaningful in that case.  This changes convergence measurement
          // only; the raw residual and Jacobian still define the Newton update.
          const Real jacobian = derivetive_(
              NewtonRaphsonFLD::dFg_deg,k,j,i);
          const Real state_scale = std::max(
              std::max(std::abs(u_gas(k,j,i)),
                       std::abs(pfld->u_gas(k,j,i))),
              static_cast<Real>(1.0e-30));
          if (std::isfinite(jacobian) && std::abs(jacobian) > TINY_NUMBER) {
            const Real backward_error = std::abs(Fg/jacobian)/state_scale;
            gas_defect_(k,j,i) = std::copysign(
                std::min(std::abs(normalized_gas_residual), backward_error),
                normalized_gas_residual);
          }
        }
        // Treat the gas-energy floor as a lower-bound constraint.  If the
        // iterate is at that bound and the unconstrained Newton direction
        // points below it, the projected residual is zero (the KKT condition
        // for the constrained local solve).  Keeping the raw residual in the
        // convergence norm would make every floor cell fail forever even
        // though AddDifference correctly refuses the inadmissible update.
        Real egas_lower_bound = TINY_NUMBER;
#if GENERAL_EOS
        const Real rho = def_coeff(NewtonRaphsonFLD::DRHO,k,j,i);
        if (std::isfinite(rho) && rho > pmy_block_->peos->GetDensityFloor()) {
          egas_lower_bound = std::max(egas_lower_bound,
              pmy_block_->peos->EgasFromRhoP(
                  rho, pmy_block_->peos->GetPressureFloor()));
        }
#endif
        const Real gas_jacobian =
            derivetive_(NewtonRaphsonFLD::dFg_deg,k,j,i);
        const Real bound_tol = 64.0*std::numeric_limits<Real>::epsilon()
            *std::max(egas_lower_bound, TINY_NUMBER);
        if (u_gas(k,j,i) <= egas_lower_bound + bound_tol
            && std::isfinite(gas_jacobian)
            && gas_jacobian > 0.0 && Fg > 0.0) {
          gas_defect_(k,j,i) = 0.0;
        }
        Real radiation_matrix_scale = 0.0;
        if (backward_error_convergence_ && !pfld->fixed_u_rad) {
          const Real fac = dt*idx2;
          radiation_matrix_scale =
              std::abs((fac*coeff(linearSolver::DCCF,k,j,i)
                        + coeff(linearSolver::DCCS,k,j,i))*center)
            + std::abs((fac*coeff(linearSolver::DXMF,k,j,i)
                        + coeff(linearSolver::DXMS,k,j,i))*neighbor[XMinus])
            + std::abs((fac*coeff(linearSolver::DXPF,k,j,i)
                        + coeff(linearSolver::DXPS,k,j,i))*neighbor[XPlus])
            + std::abs((fac*coeff(linearSolver::DYMF,k,j,i)
                        + coeff(linearSolver::DYMS,k,j,i))*neighbor[YMinus])
            + std::abs((fac*coeff(linearSolver::DYPF,k,j,i)
                        + coeff(linearSolver::DYPS,k,j,i))*neighbor[YPlus])
            + std::abs((fac*coeff(linearSolver::DZMF,k,j,i)
                        + coeff(linearSolver::DZMS,k,j,i))*neighbor[ZMinus])
            + std::abs((fac*coeff(linearSolver::DZPF,k,j,i)
                        + coeff(linearSolver::DZPS,k,j,i))*neighbor[ZPlus])
            + std::abs(src_(k,j,i));
        }
        if (pfld->fixed_u_rad) {
          def(k,j,i) = gas_defect_(k,j,i);
        } else if (pfld->only_rad) {
          def(k,j,i) = Fr/scale;
          if (backward_error_convergence_
              && std::isfinite(radiation_matrix_scale)
              && radiation_matrix_scale > TINY_NUMBER) {
            // The last few bits of E can no longer realize an accurately
            // solved correction when the diffusion matrix has O(1e13) row
            // entries.  Measure the residual also as a normwise backward
            // error of the assembled discrete row, including the unscaled
            // directed (*S) terms.  This is the radiation analogue of the
            // local gas-equation backward error above.
            const Real backward_error = std::abs(Fr)/radiation_matrix_scale;
            def(k,j,i) = std::copysign(
                std::min(std::abs(def(k,j,i)), backward_error), Fr);
          }
        } else {
          // {Fg, Fr} and {Fg, Fg+Fr} are equivalent equations.  Use the
          // latter basis, consistent with the stable Schur elimination above:
          // scaling Fr alone by Er amplifies stiff exchange roundoff by
          // Egas/Er even when total energy is balanced to machine precision.
          // Do not include the cancelling exchange term in the total scale.
          const Real gas_unsteady = u_gas(k,j,i) - pfld->u_gas(k,j,i);
          Real total_scale = std::abs(gas_unsteady) + std::abs(unsteady)
                           + dt*diffusion_scale;
          total_scale = std::max(total_scale,
              std::max(std::abs(u_gas(k,j,i) + u(k,j,i)),
                       std::abs(pfld->u_gas(k,j,i) + u_old(k,j,i))));
          total_scale = std::max(total_scale, static_cast<Real>(1.0e-30));
          // Evaluate Fg+Fr without forming either stiff exchange contribution.
          const Real total_residual = gas_unsteady + unsteady - dt*diff_term;
          def(k,j,i) = total_residual/total_scale;
          if (backward_error_convergence_
              && std::isfinite(radiation_matrix_scale)
              && radiation_matrix_scale > TINY_NUMBER) {
            const Real backward_error =
                std::abs(total_residual)/radiation_matrix_scale;
            def(k,j,i) = std::copysign(
                std::min(std::abs(def(k,j,i)), backward_error), total_residual);
          }
        }

      }
    }
  }

  return;
}


void NRFLD::CalculateAdditionalDefectNorms(Real &l2_sum, Real &max_norm,
                                           bool &active, bool &finite) const {
  const FLD *fld = pmy_block_->prfld;
  // The gas correction is eliminated locally from the one-variable radiation
  // solve.  In the ordinary coupled mode it is nevertheless an independent
  // nonlinear residual and must participate in convergence control.  It is
  // not an unknown equation in only_rad mode, while fixed_u_rad makes it the
  // primary (and only) residual instead.
  active = !fld->fixed_u_rad && !fld->only_rad;
  l2_sum = 0.0;
  max_norm = 0.0;
  finite = true;
  if (!active) return;

  const int il = pmy_block_->is, iu = pmy_block_->ie;
  const int jl = pmy_block_->js, ju = pmy_block_->je;
  const int kl = pmy_block_->ks, ku = pmy_block_->ke;
  const Real dx = pmy_block_->pcoord->dx1f(il);
  const Real dy = pmy_block_->pcoord->dx2f(jl);
  const Real dz = pmy_block_->pcoord->dx3f(kl);
  Real sum = 0.0;
  Real maximum = 0.0;
  for (int k = kl; k <= ku; ++k) {
    for (int j = jl; j <= ju; ++j) {
#pragma omp simd reduction(+: sum) reduction(max: maximum)
      for (int i = il; i <= iu; ++i) {
        const Real value = gas_defect_(k,j,i);
        const Real abs_value = std::abs(value);
        sum += SQR(abs_value);
        maximum = std::max(maximum, abs_value);
      }
    }
  }
  l2_sum = sum*dx*dy*dz;
  max_norm = maximum;
  finite = std::isfinite(l2_sum) && std::isfinite(max_norm);
}

bool NRFLD::PrimaryDefectIsGas() const {
  return pmy_block_->prfld->fixed_u_rad;
}

bool NRFLD::PrimaryDefectIsTotalEnergy() const {
  const FLD *fld = pmy_block_->prfld;
  return !fld->fixed_u_rad && !fld->only_rad;
}


// delta is reset to zero in this function
void NRFLD::AddDifference(AthenaArray<Real> &u_rad,
                          AthenaArray<Real> &delta_u,
                          const AthenaArray<Real> &derivetive) {

  int is = pmy_block_->is;
  int ie = pmy_block_->ie;
  int js = pmy_block_->js;
  int je = pmy_block_->je;
  int ks = pmy_block_->ks;
  int ke = pmy_block_->ke;
  FLD *pfld = pmy_block_->prfld;
  const Real step_scale = pmy_driver_->step_scale_;
  const bool mixed_active = pfld->MixedFrameCoupled()
      && pfld->implicit_mixed_frame_drift;
  int exact_local_gas_cells = 0;
  Real exact_local_gas_residual_max = 0.0;

  if (pmy_driver_->diagnostic_verbosity_ >= 2) {
    for (int k = 0; k < delta_u.GetDim3(); ++k)
      for (int j = 0; j < delta_u.GetDim2(); ++j)
        for (int i = 0; i < delta_u.GetDim1(); ++i)
          last_delta_rad_(0,k,j,i) = last_delta_rad_(1,k,j,i) = delta_u(k,j,i);
  }

  if (mixed_active) {
    // The gas correction contains a stencil of the radiation correction.
    // Compute the correction actually applied at every stencil point before
    // changing any active cell.  With a per-cell cap or positivity floor this
    // differs from the raw multigrid direction in neighboring cells.
    for (int k = 0; k < delta_u.GetDim3(); ++k) {
      for (int j = 0; j < delta_u.GetDim2(); ++j) {
        for (int i = 0; i < delta_u.GetDim1(); ++i) {
          Real delta = pfld->fixed_u_rad ? 0.0 : delta_u(k,j,i);
          delta = LimitNewtonCorrection(delta,
              std::max(std::abs(u_rad(k,j,i)), TINY_NUMBER),
              max_update_fraction_);
          const Real next = u_rad(k,j,i) + step_scale*delta;
          const Real applied = pfld->fixed_u_rad ? 0.0
              : ((std::isfinite(next) && next > TINY_NUMBER)
                 ? next - u_rad(k,j,i) : TINY_NUMBER - u_rad(k,j,i));
          last_delta_rad_(1,k,j,i) = applied/step_scale;
        }
      }
    }
  }

  for (int k=ks; k<=ke; ++k) {
    for (int j=js; j<=je; ++j) {
      for (int i=is; i<=ie; ++i) {
        const Real raw_delta_ur = delta_u(k,j,i);
        Real delta_ur = pfld->fixed_u_rad ? 0.0 : raw_delta_ur;
        delta_ur = LimitNewtonCorrection(delta_ur,
            std::max(std::abs(u_rad(k,j,i)), TINY_NUMBER),
            max_update_fraction_);
        const Real scaled_delta_ur = step_scale*delta_ur;
        const Real u_rad_before = u_rad(k,j,i);
        if (!pfld->fixed_u_rad) {
          const Real ur_next = u_rad(k,j,i) + scaled_delta_ur;
          u_rad(k,j,i) = (std::isfinite(ur_next) && ur_next > TINY_NUMBER)
                         ? ur_next : TINY_NUMBER;
        } else {
          // Enforce the prescribed value explicitly on every NR iteration.
          u_rad(k,j,i) = uold_(k,j,i);
        }
        last_delta_rad_(0,k,j,i) = raw_delta_ur;
        if (!mixed_active)
          last_delta_rad_(1,k,j,i) = u_rad(k,j,i) - u_rad_before;

        const Real denom = derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i);
        const Real mixed_delta = mixed_active ? MixedDriftCorrection(
            mixed_drift_, last_delta_rad_, k,j,i,
            0.5/pmy_block_->pcoord->dx1f(is)) : 0.0;
        // Reconstruct the gas correction from the radiation correction that
        // will actually be applied.  In the non-mixed case last_delta_rad_
        // stores the applied update (including a positivity-floor clip), while
        // the elimination formula expects an unscaled Newton direction.
        // Using delta_ur here would make the gas and radiation components
        // inconsistent whenever the positivity floor clips the trial update.
        const Real coupled_delta_ur = mixed_active ? last_delta_rad_(1,k,j,i)
            : last_delta_rad_(1,k,j,i)/step_scale;
        const Real egas_delta = -(derivetive(NewtonRaphsonFLD::Fg,k,j,i)
            + derivetive(NewtonRaphsonFLD::dFg_dEr,k,j,i)*coupled_delta_ur
            - pmy_driver_->dt_*mixed_delta)/denom;
        Real egas_floor = TINY_NUMBER;
#if GENERAL_EOS
        const Real rho = pmy_block_->phydro->w(IDN,k,j,i);
        if (std::isfinite(rho) && rho > pmy_block_->peos->GetDensityFloor()) {
          egas_floor = std::max(egas_floor,
              pmy_block_->peos->EgasFromRhoP(rho, pmy_block_->peos->GetPressureFloor()));
        }
#endif
        bool local_gas_solved = false;
#if GENERAL_EOS && EOS_TABLE_ENABLED
        // In the optically stiff limit a global radiation correction can move
        // Er by orders of magnitude.  A single linearized gas correction then
        // leaves a large LTE residual and can cease to be a descent direction.
        // For a table EOS, eliminate the monotone local matter equation exactly
        // at the newly applied Er.  The old gas state and the LTE state bracket
        // the root; a pressure floor turns the solve into a lower-bound problem.
        if (exact_local_gas_solve_ && pfld->is_couple && !pfld->only_rad) {
          const Real rho = pmy_block_->phydro->w(IDN,k,j,i);
          const Real egas_old = pfld->u_gas(k,j,i);
          const Real c_sigma_p = pfld->c_ph*pfld->sigma_p(k,j,i);
          const Real current_egas = u_gas_(k,j,i);
          const Real current_temperature = pmy_block_->peos->TempFromRhoEg(
              rho, current_egas);
          const Real current_t2 = current_temperature*current_temperature;
          const Real current_equilibrium = pfld->a_r*current_t2*current_t2;
          const Real radiation_change = u_rad(k,j,i)-u_rad_before;
          auto gas_residual = [&](const Real egas) {
            const Real temperature = pmy_block_->peos->TempFromRhoEg(rho, egas);
            const Real t2 = temperature*temperature;
            const Real equilibrium = pfld->a_r*t2*t2;
            if (mixed_active) {
              // Fg at the current Newton state already includes the old
              // mixed-frame drift. Its change under the applied radiation
              // correction is linear for frozen face coefficients.
              return derivetive(NewtonRaphsonFLD::Fg,k,j,i)
                  + (egas-current_egas)
                  + pmy_driver_->dt_*c_sigma_p
                      *(equilibrium-current_equilibrium-radiation_change)
                  - pmy_driver_->dt_*step_scale*mixed_delta;
            }
            return (egas-egas_old) + pmy_driver_->dt_*c_sigma_p
                *ResolvableThermalDifference(equilibrium, u_rad(k,j,i));
          };
          // With diffusion disabled, the second local equation is exactly
          // egas + Er = egas_old + Er_old.  Solve that one-dimensional system
          // directly instead of recovering Er by subtracting two large gas
          // energies.  The latter loses the small radiation state before the
          // stiff exchange coefficient magnifies its rounding error.
          if (pfld->cut_diff && !pfld->fixed_u_rad && !mixed_active) {
            const Real erad_old = uold_(k,j,i);
            const Real total = egas_old + erad_old;
            const Real upper_bound = std::nextafter(
                total, -std::numeric_limits<Real>::infinity());
            const Real radiation_temperature = std::pow(
                std::max(erad_old, TINY_NUMBER)/pfld->a_r, 0.25);
            const Real egas_lte = pmy_block_->peos->EgasFromRhoT(
                rho, radiation_temperature);
            const Real bracket_upper = std::min(
                upper_bound, std::max(egas_old, egas_lte));
            if (std::isfinite(egas_lte) && std::isfinite(bracket_upper)
                && bracket_upper > egas_floor) {
              auto coupled_residual = [&](const Real egas) {
                const Real erad = erad_old + (egas_old-egas);
                const Real temperature = pmy_block_->peos->TempFromRhoEg(
                    rho, egas);
                const Real t2 = temperature*temperature;
                return (egas-egas_old) + pmy_driver_->dt_*c_sigma_p
                    *ResolvableThermalDifference(pfld->a_r*t2*t2, erad);
              };
              const Real f_lower = coupled_residual(egas_floor);
              const Real f_upper = coupled_residual(bracket_upper);
              if (std::isfinite(f_lower) && std::isfinite(f_upper)
                  && f_upper >= 0.0) {
                Real lower = egas_floor;
                Real upper = bracket_upper;
                if (f_lower >= 0.0) {
                  upper = lower;
                } else {
                  for (int iteration=0; iteration<64; ++iteration) {
                    const Real middle = 0.5*(lower+upper);
                    if (middle == lower || middle == upper) break;
                    const Real f_middle = coupled_residual(middle);
                    if (!std::isfinite(f_middle)) break;
                    if (f_middle < 0.0) lower = middle;
                    else upper = middle;
                  }
                }
                const Real egas = 0.5*(lower+upper);
                const Real erad = erad_old + (egas_old-egas);
                if (std::isfinite(erad) && erad > TINY_NUMBER) {
                  u_gas_(k,j,i) = egas;
                  u_rad(k,j,i) = erad;
                  last_delta_rad_(1,k,j,i) = erad-u_rad_before;
                  local_gas_solved = true;
                }
              }
            }
          }
          if (!local_gas_solved) {
            const Real f_floor = gas_residual(egas_floor);
            if (std::isfinite(f_floor) && f_floor >= 0.0) {
              u_gas_(k,j,i) = egas_floor;
              local_gas_solved = true;
            } else if (std::isfinite(f_floor)) {
              const Real radiation_temperature = std::pow(
                  std::max(u_rad(k,j,i), TINY_NUMBER)/pfld->a_r, 0.25);
              const Real egas_lte = pmy_block_->peos->EgasFromRhoT(
                  rho, radiation_temperature);
              if (std::isfinite(egas_lte) && egas_lte > 0.0) {
                Real lower = egas_floor;
                Real upper = std::max({egas_floor, egas_old, egas_lte});
                Real f_upper = gas_residual(upper);
                if (std::isfinite(f_upper) && f_upper >= 0.0) {
                  for (int iteration=0; iteration<64; ++iteration) {
                    const Real middle = 0.5*(lower+upper);
                    const Real f_middle = gas_residual(middle);
                    if (!std::isfinite(f_middle)) break;
                    if (f_middle < 0.0) lower = middle;
                    else upper = middle;
                    if (upper-lower <= 8.0*std::numeric_limits<Real>::epsilon()
                        *std::max(upper, egas_floor)) break;
                  }
                  u_gas_(k,j,i) = 0.5*(lower+upper);
                  local_gas_solved = true;
                }
              }
            }
          }
          if (local_gas_solved) {
            ++exact_local_gas_cells;
            const Real local_scale = std::max(
                std::abs(u_gas_(k,j,i)) + std::abs(egas_old),
                static_cast<Real>(1.0e-30));
            exact_local_gas_residual_max = std::max(
                exact_local_gas_residual_max,
                std::abs(gas_residual(u_gas_(k,j,i)))/local_scale);
          }
        }
#endif
        if (!local_gas_solved) {
          Real limited_egas_delta = LimitNewtonCorrection(
              egas_delta, std::max(std::abs(u_gas_(k,j,i)), egas_floor),
              max_update_fraction_);
          const Real egas_next =
              u_gas_(k,j,i) + step_scale*limited_egas_delta;
          u_gas_(k,j,i) =
              (std::isfinite(egas_next) && egas_next > egas_floor)
              ? egas_next : egas_floor;
        }
        
        // Keep the linear correction for possible line-search retries.  The
        // driver clears it before computing the next Newton direction.
      }
    }
  }
  // The mixed stencil above must see the same precomputed correction for all
  // cells.  Restore the diagnostic slot's usual applied-delta units afterward.
  if (mixed_active) {
    for (int k = ks; k <= ke; ++k)
      for (int j = js; j <= je; ++j)
        for (int i = is; i <= ie; ++i)
          last_delta_rad_(1,k,j,i) *= step_scale;
  }
  if (pmy_driver_->diagnostic_verbosity_ >= 1 && pmy_block_->gid == 0
      && Globals::my_rank == 0)
    std::cout << "[NR_LOCAL_GAS] exact_cells=" << exact_local_gas_cells
              << " residual_over_gas_scale_max=" << exact_local_gas_residual_max
              << " mixed_active=" << mixed_active << std::endl;
  // if(pmy_driver_->fshowdef_)  {
  //   int k = (ks + ke) / 2;
  //   int j = (js + je) / 2;
  //   int i = (is + ie) / 2;
  //   Real u_gas_delta = -(derivetive(NewtonRaphsonFLD::Fg,k,j,i) + derivetive(NewtonRaphsonFLD::dFg_dEr,k,j,i)*delta_u(k,j,i)) / derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i);
  //   std::cout << "At (" << k << "," << j << "," << i << "):" << std::endl;
  //   std::cout << "u_rad_delta = " << delta_u(k,j,i) << std::endl;
  //   std::cout << "u_gas_delta = " << u_gas_delta << std::endl;
  //   std::cout << "derivetive.Fg = " << derivetive(NewtonRaphsonFLD::Fg,k,j,i)
  //             << ", derivetive.dFg_dEr = " << derivetive(NewtonRaphsonFLD::dFg_dEr,k,j,i)
  //             << ", derivetive.dFg_deg = " << derivetive(NewtonRaphsonFLD::dFg_deg,k,j,i) << std::endl;
  // }
  return;
}

void NRFLD::ApplyPhysicalBoundary() {
  for (int dir = 0; dir < 6; dir++) {
    // check if neighbor block exists
    if (pmy_block_->pbval->block_bcs[dir] == BoundaryFlag::block) continue;
    BoundaryFace face = static_cast<BoundaryFace>(dir);
    BoundaryFlag bflag = pmy_driver_->nr_mesh_bcs_[dir];
    // To do: add other boundary conditions like outflow
    if (bflag == BoundaryFlag::user) {
      pmy_driver_->NRBoundaryFunction_[dir](pmy_block_, u_, u_gas_,
      pmy_block_->pcoord, pmy_block_->phydro->w,
      pmy_block_->pmy_mesh->time, pmy_driver_->dt_,
      pmy_block_->is, pmy_block_->ie,
      pmy_block_->js, pmy_block_->je,
      pmy_block_->ks, pmy_block_->ke,
      NGHOST);
    }
  }

  if (pmy_block_->prfld->fixed_u_rad) {
    int il = pmy_block_->is - NGHOST, iu = pmy_block_->ie + NGHOST;
    int jl = pmy_block_->js, ju = pmy_block_->je;
    int kl = pmy_block_->ks, ku = pmy_block_->ke;
    if (pmy_block_->pmy_mesh->f2) jl -= NGHOST, ju += NGHOST;
    if (pmy_block_->pmy_mesh->f3) kl -= NGHOST, ku += NGHOST;
    for (int k = kl; k <= ku; ++k) {
      for (int j = jl; j <= ju; ++j) {
        for (int i = il; i <= iu; ++i) {
          u_(k,j,i) = uold_(k,j,i);
        }
      }
    }
  }
  
  return;
}

void NRFLD::PrintFailurePhysicsDebug(Real gas_max) {
  if (!(gas_max > 0.0) || !std::isfinite(gas_max)) return;
  MeshBlock *mb = pmy_block_;
  FLD *fld = mb->prfld;
  for (int k=mb->ks; k<=mb->ke; ++k)
    for (int j=mb->js; j<=mb->je; ++j)
      for (int i=mb->is; i<=mb->ie; ++i) {
        // MPI_MAX preserves the selected value exactly. Print only cells
        // attaining that global maximum, not one diagnostic per MPI rank.
        if (std::abs(gas_defect_(k,j,i)) != gas_max) continue;
        const Real rho = def_coeff_(NewtonRaphsonFLD::DRHO,k,j,i);
        Real egas_floor = TINY_NUMBER;
        Real dT_deg = def_coeff_(NewtonRaphsonFLD::DCOUPLE,k,j,i);
#if GENERAL_EOS
        const Real temperature = mb->peos->TempFromRhoEg(rho, u_gas_(k,j,i));
        dT_deg = temperature/u_gas_(k,j,i)
            *mb->peos->DlnTDlnEgasFromRhoEg(rho, u_gas_(k,j,i));
        if (rho > mb->peos->GetDensityFloor()) {
          egas_floor = std::max(egas_floor,
              mb->peos->EgasFromRhoP(rho, mb->peos->GetPressureFloor()));
        }
#else
        const Real temperature = def_coeff_(NewtonRaphsonFLD::DCOUPLE,k,j,i)
                                 *u_gas_(k,j,i);
#endif
        const Real t2 = temperature*temperature;
        const Real equilibrium = fld->a_r*t2*t2;
        const Real thermal = ResolvableThermalDifference(equilibrium, u_(k,j,i));
        std::cout << "[NR_GAS_FAILURE] rank=" << Globals::my_rank
                  << " gid=" << mb->gid
                  << " cycle=" << mb->pmy_mesh->ncycle
                  << " time=" << mb->pmy_mesh->time
                  << " k=" << k << " j=" << j << " i=" << i
                  << " x=" << mb->pcoord->x1v(i)
                  << " y=" << mb->pcoord->x2v(j)
                  << " z=" << mb->pcoord->x3v(k)
                  << " signed_gas_defect=" << gas_defect_(k,j,i)
                  << " rho=" << rho << " egas=" << u_gas_(k,j,i)
                  << " egas_old=" << fld->u_gas(k,j,i)
                  << " egas_floor=" << egas_floor
                  << " gas_at_floor=" << (u_gas_(k,j,i) <= egas_floor)
                  << " dT_deg_initial=" << def_coeff_(NewtonRaphsonFLD::DCOUPLE,k,j,i)
                  << " dT_deg_current=" << dT_deg
                  << " erad=" << u_(k,j,i) << " temperature=" << temperature
                  << " equilibrium_erad=" << equilibrium
                  << " raw_thermal_difference=" << equilibrium-u_(k,j,i)
                  << " dt_source=" << pmy_driver_->dt_*fld->c_ph
                                     *fld->sigma_p(k,j,i)*thermal
                  << std::endl;
        return;  // At most one tied maximum per MeshBlock.
      }
}

void NRFLD::PrintCellPhysicsDebug(int k, int j, int i) {
  FLD *pfld = pmy_block_->prfld;
  const AthenaArray<Real> &u_pre = u_;
  const AthenaArray<Real> &sigma_r = pfld->sigma_r;
  const AthenaArray<Real> &coeff = coeff_;
  const AthenaArray<Real> &src = src_;
  const Real dx = pmy_block_->pcoord->dx1f(i);
  const Real dy = pmy_block_->pcoord->dx2f(j);
  const Real dz = pmy_block_->pcoord->dx3f(k);
  const Real idx = 1.0/dx;
  const Real idy = 1.0/dy;
  const Real idz = 1.0/dz;
  const Real fac = pmy_driver_->dt_/SQR(dx);

  auto print_face = [&](const char *label, Real sigma_face, Real gx, Real gy, Real gz,
                        Real e_face, Real coeff_face) {
    const Real grad_face = FaceGradient(gx, gy, gz);
    const RadFLD::ClosureValues closure = RequireFaceClosure(
        grad_face, sigma_face, e_face, pfld->fixed_flux_limiter,
        label, k, j, i);
    Real r_face = 0.0;
    if (grad_face > 0.0 && (sigma_face == 0.0 || e_face == 0.0)) {
      r_face = std::numeric_limits<Real>::infinity();
    } else if (grad_face > 0.0) {
      r_face = static_cast<Real>(static_cast<long double>(grad_face)
          / static_cast<long double>(sigma_face)
          / static_cast<long double>(e_face));
    }
    std::cout << "      " << label
              << " sigma_face=" << sigma_face
              << " E_face=" << e_face
              << " gradE_face=" << grad_face
              << " R_face=" << r_face
              << " lambda_face=" << closure.lambda
              << " dFr_coeff=" << coeff_face
              << std::endl;
  };

  Real sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j,i-1), idx);
  Real gx = (u_pre(k,j,i-1) - u_pre(k,j,i))*idx;
  Real gy = 0.25*idy*((u_pre(k,j+1,i-1) - u_pre(k,j-1,i-1)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
  Real gz = 0.25*idz*((u_pre(k+1,j,i-1) - u_pre(k-1,j,i-1)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
  Real e_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j,i-1));
  print_face("face_xm", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_xm, k, j, i));

  sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j,i+1), idx);
  gx = (u_pre(k,j,i+1) - u_pre(k,j,i))*idx;
  gy = 0.25*idy*((u_pre(k,j+1,i+1) - u_pre(k,j-1,i+1)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
  gz = 0.25*idz*((u_pre(k+1,j,i+1) - u_pre(k-1,j,i+1)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
  e_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j,i+1));
  print_face("face_xp", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_xp, k, j, i));

  sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j-1,i), idx);
  gx = 0.25*idx*((u_pre(k,j-1,i+1) - u_pre(k,j-1,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
  gy = (u_pre(k,j-1,i) - u_pre(k,j,i))*idy;
  gz = 0.25*idz*((u_pre(k+1,j-1,i) - u_pre(k-1,j-1,i)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
  e_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j-1,i));
  print_face("face_ym", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_ym, k, j, i));

  sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k,j+1,i), idx);
  gx = 0.25*idx*((u_pre(k,j+1,i+1) - u_pre(k,j+1,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
  gy = (u_pre(k,j+1,i) - u_pre(k,j,i))*idy;
  gz = 0.25*idz*((u_pre(k+1,j+1,i) - u_pre(k-1,j+1,i)) + (u_pre(k+1,j,i) - u_pre(k-1,j,i)));
  e_face = FaceEnergy(u_pre(k,j,i), u_pre(k,j+1,i));
  print_face("face_yp", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_yp, k, j, i));

  sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k-1,j,i), idx);
  gx = 0.25*idx*((u_pre(k-1,j,i+1) - u_pre(k-1,j,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
  gy = 0.25*idy*((u_pre(k-1,j+1,i) - u_pre(k-1,j-1,i)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
  gz = (u_pre(k-1,j,i) - u_pre(k,j,i))*idz;
  e_face = FaceEnergy(u_pre(k,j,i), u_pre(k-1,j,i));
  print_face("face_zm", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_zm, k, j, i));

  sigma_face = RadFLD::FaceOpacity(sigma_r(k,j,i), sigma_r(k+1,j,i), idx);
  gx = 0.25*idx*((u_pre(k+1,j,i+1) - u_pre(k+1,j,i-1)) + (u_pre(k,j,i+1) - u_pre(k,j,i-1)));
  gy = 0.25*idy*((u_pre(k+1,j+1,i) - u_pre(k+1,j-1,i)) + (u_pre(k,j+1,i) - u_pre(k,j-1,i)));
  gz = (u_pre(k+1,j,i) - u_pre(k,j,i))*idz;
  e_face = FaceEnergy(u_pre(k,j,i), u_pre(k+1,j,i));
  print_face("face_zp", sigma_face, gx, gy, gz, e_face,
             derivetive_(NewtonRaphsonFLD::dFr_dEr_zp, k, j, i));

  const Real m_cc = fac*coeff(linearSolver::DCCF,k,j,i) + coeff(linearSolver::DCCS,k,j,i);
  const Real m_xm = fac*coeff(linearSolver::DXMF,k,j,i);
  const Real m_xp = fac*coeff(linearSolver::DXPF,k,j,i);
  const Real m_ym = fac*coeff(linearSolver::DYMF,k,j,i);
  const Real m_yp = fac*coeff(linearSolver::DYPF,k,j,i);
  const Real m_zm = fac*coeff(linearSolver::DZMF,k,j,i);
  const Real m_zp = fac*coeff(linearSolver::DZPF,k,j,i);

  const Real delta_raw_c = last_delta_rad_(0,k,j,i);
  const Real delta_raw_xm = last_delta_rad_(0,k,j,i-1);
  const Real delta_raw_xp = last_delta_rad_(0,k,j,i+1);
  const Real delta_raw_ym = last_delta_rad_(0,k,j-1,i);
  const Real delta_raw_yp = last_delta_rad_(0,k,j+1,i);
  const Real delta_raw_zm = last_delta_rad_(0,k-1,j,i);
  const Real delta_raw_zp = last_delta_rad_(0,k+1,j,i);
  const Real m_delta_raw = m_cc*delta_raw_c
      + m_xm*delta_raw_xm + m_xp*delta_raw_xp
      + m_ym*delta_raw_ym + m_yp*delta_raw_yp
      + m_zm*delta_raw_zm + m_zp*delta_raw_zp;

  // The active cells of u_iter_backup_ contain the exact pre-trial iterate,
  // but its ghost zones are not exchanged after StoreIterate().  Therefore an
  // applied-correction stencil is meaningful only when all seven cells are
  // active cells of this MeshBlock.  Report NaN at a block edge instead of
  // manufacturing a large operator mismatch from stale backup ghosts.
  const bool applied_stencil_local =
      i > pmy_block_->is && i < pmy_block_->ie
      && j > pmy_block_->js && j < pmy_block_->je
      && k > pmy_block_->ks && k < pmy_block_->ke;
  const Real unavailable = std::numeric_limits<Real>::quiet_NaN();
  const Real delta_app_c = u_(k,j,i) - u_iter_backup_(k,j,i);
  const Real delta_app_xm = applied_stencil_local
      ? u_(k,j,i-1) - u_iter_backup_(k,j,i-1) : unavailable;
  const Real delta_app_xp = applied_stencil_local
      ? u_(k,j,i+1) - u_iter_backup_(k,j,i+1) : unavailable;
  const Real delta_app_ym = applied_stencil_local
      ? u_(k,j-1,i) - u_iter_backup_(k,j-1,i) : unavailable;
  const Real delta_app_yp = applied_stencil_local
      ? u_(k,j+1,i) - u_iter_backup_(k,j+1,i) : unavailable;
  const Real delta_app_zm = applied_stencil_local
      ? u_(k-1,j,i) - u_iter_backup_(k-1,j,i) : unavailable;
  const Real delta_app_zp = applied_stencil_local
      ? u_(k+1,j,i) - u_iter_backup_(k+1,j,i) : unavailable;
  const Real m_delta_applied = applied_stencil_local
      ? m_cc*delta_app_c + m_xm*delta_app_xm + m_xp*delta_app_xp
        + m_ym*delta_app_ym + m_yp*delta_app_yp
        + m_zm*delta_app_zm + m_zp*delta_app_zp
      : unavailable;

  std::cout << "      linear_row"
            << " m_cc=" << m_cc
            << " m_xm=" << m_xm
            << " m_xp=" << m_xp
            << " m_ym=" << m_ym
            << " m_yp=" << m_yp
            << " m_zm=" << m_zm
            << " m_zp=" << m_zp
            << std::endl;
  std::cout << "      delta_raw"
            << " c=" << delta_raw_c
            << " xm=" << delta_raw_xm
            << " xp=" << delta_raw_xp
            << " ym=" << delta_raw_ym
            << " yp=" << delta_raw_yp
            << " zm=" << delta_raw_zm
            << " zp=" << delta_raw_zp
            << std::endl;
  std::cout << "      delta_applied"
            << " stencil_local=" << applied_stencil_local
            << " c=" << delta_app_c
            << " xm=" << delta_app_xm
            << " xp=" << delta_app_xp
            << " ym=" << delta_app_ym
            << " yp=" << delta_app_yp
            << " zm=" << delta_app_zm
            << " zp=" << delta_app_zp
            << std::endl;
  std::cout << "      linear_balance"
            << " src=" << src(k,j,i)
            << " A_delta_raw=" << m_delta_raw
            << " src_minus_A_delta_raw=" << (src(k,j,i) - m_delta_raw)
            << " A_delta_applied=" << m_delta_applied
            << " src_minus_A_delta_applied=" << (src(k,j,i) - m_delta_applied)
            << std::endl;
}
